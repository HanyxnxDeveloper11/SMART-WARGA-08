package com.example

import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FormatUtilsTest {

    @Test
    fun testMaskNik() {
        val nik = "3276011405680001"
        val masked = FormatUtils.maskNik(nik)
        assertEquals("3276********0001", masked)
    }

    @Test
    fun testMaskNoKk() {
        val noKk = "3276011002010001"
        val masked = FormatUtils.maskNoKk(noKk)
        assertEquals("3276********0001", masked)
    }

    @Test
    fun testMaskPhone() {
        val phone = "081288339001"
        val masked = FormatUtils.maskPhone(phone)
        assertEquals("0812****9001", masked)
    }

    @Test
    fun testGenerateNomorSurat() {
        val nomor = FormatUtils.generateNomorSurat(1)
        assertTrue(nomor.contains("/RT.05/RW.08/"))
    }
}
