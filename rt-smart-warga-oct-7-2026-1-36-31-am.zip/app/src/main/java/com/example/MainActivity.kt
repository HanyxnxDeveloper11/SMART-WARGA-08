package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.ui.components.RoleBadge
import com.example.ui.navigation.NavScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.IuranScreen
import com.example.ui.screens.KasScreen
import com.example.ui.screens.KegiatanScreen
import com.example.ui.screens.LaporanScreen
import com.example.ui.screens.PengumumanScreen
import com.example.ui.screens.ProfilScreen
import com.example.ui.screens.SuratScreen
import com.example.ui.screens.WargaScreen
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.RTSmartWargaTheme
import com.example.ui.viewmodel.RTViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: RTViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            RTSmartWargaTheme {
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
                val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
                val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()

                val snackbarHostState = remember { SnackbarHostState() }
                var showRoleSwitcherDialog by remember { mutableStateOf(false) }
                var showMoreMenuSheet by remember { mutableStateOf(false) }

                LaunchedEffect(Unit) {
                    viewModel.toastEvent.collect { message ->
                        snackbarHostState.showSnackbar(message)
                    }
                }

                // Handle system back navigation
                BackHandler(enabled = currentScreen != NavScreen.BERANDA) {
                    viewModel.handleBackPress()
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        CenterAlignedTopAppBar(
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = NavyPrimary,
                                titleContentColor = Color.White,
                                navigationIconContentColor = Color.White,
                                actionIconContentColor = Color.White
                            ),
                            navigationIcon = {
                                if (currentScreen != NavScreen.BERANDA) {
                                    IconButton(
                                        onClick = { viewModel.handleBackPress() },
                                        modifier = Modifier.testTag("top_back_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowBack,
                                            contentDescription = "Kembali",
                                            tint = Color.White
                                        )
                                    }
                                } else {
                                    IconButton(
                                        onClick = { showMoreMenuSheet = true },
                                        modifier = Modifier.testTag("top_menu_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Menu,
                                            contentDescription = "Menu",
                                            tint = Color.White
                                        )
                                    }
                                }
                            },
                            title = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = currentScreen.title,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "RT 05 / RW 08 Sukamaju",
                                        fontSize = 11.sp,
                                        color = Color.White.copy(alpha = 0.75f)
                                    )
                                }
                            },
                            actions = {
                                Surface(
                                    color = Color.White.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .clickable { showRoleSwitcherDialog = true }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(GreenAccent)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = when (currentRole) {
                                                UserRole.ADMIN_KETUA_RT -> "Ketua RT"
                                                UserRole.BENDAHARA -> "Bendahara"
                                                UserRole.SEKRETARIS -> "Sekretaris"
                                                UserRole.WARGA -> "Warga"
                                            },
                                            fontSize = 11.sp,
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Icon(
                                            imageVector = Icons.Default.SwapHoriz,
                                            contentDescription = "Ganti Peran",
                                            tint = Color.White,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .padding(start = 2.dp)
                                        )
                                    }
                                }
                            }
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp,
                            modifier = Modifier.testTag("bottom_nav_bar")
                        ) {
                            val mainTabs = listOf(
                                NavScreen.BERANDA,
                                NavScreen.WARGA,
                                NavScreen.KAS,
                                NavScreen.IURAN
                            )

                            mainTabs.forEach { screen ->
                                val isSelected = currentScreen == screen
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { viewModel.navigateTo(screen) },
                                    icon = {
                                        Icon(
                                            imageVector = screen.icon,
                                            contentDescription = screen.title
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = screen.title,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = NavyPrimary,
                                        selectedTextColor = NavyPrimary,
                                        indicatorColor = NavyPrimary.copy(alpha = 0.12f),
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    )
                                )
                            }

                            // 5th Tab: Lainnya (Menu Lengkap)
                            val isLainnyaSelected = currentScreen in listOf(
                                NavScreen.KEGIATAN,
                                NavScreen.PENGUMUMAN,
                                NavScreen.SURAT,
                                NavScreen.LAPORAN,
                                NavScreen.PROFIL
                            )

                            NavigationBarItem(
                                selected = isLainnyaSelected,
                                onClick = { showMoreMenuSheet = true },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.MoreHoriz,
                                        contentDescription = "Menu Lainnya"
                                    )
                                },
                                label = {
                                    Text(
                                        text = if (isLainnyaSelected) currentScreen.title else "Lainnya",
                                        fontSize = 11.sp,
                                        fontWeight = if (isLainnyaSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NavyPrimary,
                                    selectedTextColor = NavyPrimary,
                                    indicatorColor = NavyPrimary.copy(alpha = 0.12f),
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray
                                )
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "ScreenTransition"
                        ) { target ->
                            when (target) {
                                NavScreen.BERANDA -> DashboardScreen(
                                    viewModel = viewModel,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                                NavScreen.WARGA -> WargaScreen(viewModel = viewModel)
                                NavScreen.KAS -> KasScreen(viewModel = viewModel)
                                NavScreen.IURAN -> IuranScreen(viewModel = viewModel)
                                NavScreen.KEGIATAN -> KegiatanScreen(viewModel = viewModel)
                                NavScreen.PENGUMUMAN -> PengumumanScreen(viewModel = viewModel)
                                NavScreen.SURAT -> SuratScreen(viewModel = viewModel)
                                NavScreen.LAPORAN -> LaporanScreen(viewModel = viewModel)
                                NavScreen.PROFIL -> ProfilScreen(viewModel = viewModel)
                            }
                        }
                    }
                }

                // Modal Bottom Sheet for All Menus
                if (showMoreMenuSheet) {
                    ModalBottomSheet(
                        onDismissRequest = { showMoreMenuSheet = false },
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "Semua Menu RT Smart Warga",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            val allScreens = listOf(
                                NavScreen.BERANDA,
                                NavScreen.WARGA,
                                NavScreen.KAS,
                                NavScreen.IURAN,
                                NavScreen.KEGIATAN,
                                NavScreen.PENGUMUMAN,
                                NavScreen.SURAT,
                                NavScreen.LAPORAN,
                                NavScreen.PROFIL
                            )

                            allScreens.forEach { screen ->
                                val isCurrent = currentScreen == screen
                                Surface(
                                    color = if (isCurrent) NavyPrimary.copy(alpha = 0.1f) else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.navigateTo(screen)
                                            showMoreMenuSheet = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = screen.icon,
                                            contentDescription = screen.title,
                                            tint = if (isCurrent) NavyPrimary else Color.DarkGray,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Text(
                                            text = screen.title,
                                            fontSize = 14.sp,
                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isCurrent) NavyPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(30.dp))
                        }
                    }
                }

                // Role Switcher Dialog accessible anytime
                if (showRoleSwitcherDialog) {
                    AlertDialog(
                        onDismissRequest = { showRoleSwitcherDialog = false },
                        title = {
                            Text(text = "Uji Hak Akses / Ganti Role", fontWeight = FontWeight.Bold)
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "Pilih akun di bawah untuk melihat perbedaan tampilan sesuai peran:",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                allUsers.forEach { user ->
                                    val isCurrent = user.id == currentUser?.id
                                    val uRole = try { UserRole.valueOf(user.role) } catch (e: Exception) { UserRole.WARGA }

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isCurrent) NavyPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isCurrent) NavyPrimary else Color(0xFFCBD5E1)
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.switchUser(user)
                                                showRoleSwitcherDialog = false
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = user.nama,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "${uRole.label} (${user.email})",
                                                    fontSize = 11.sp,
                                                    color = NavyPrimary
                                                )
                                            }
                                            if (isCurrent) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "Aktif",
                                                    tint = GreenAccent,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showRoleSwitcherDialog = false }) {
                                Text("Tutup")
                            }
                        }
                    )
                }
            }
        }
    }
}
