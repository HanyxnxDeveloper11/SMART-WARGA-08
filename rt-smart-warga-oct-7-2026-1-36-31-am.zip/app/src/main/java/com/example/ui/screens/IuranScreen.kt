package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.IuranEntity
import com.example.data.model.UserRole
import com.example.data.model.WargaEntity
import com.example.ui.components.StatCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel
import com.example.util.FormatUtils

@Composable
fun IuranScreen(
    viewModel: RTViewModel
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val allIuran by viewModel.allIuran.collectAsStateWithLifecycle()
    val summary by viewModel.iuranSummary.collectAsStateWithLifecycle()
    val wargaList by viewModel.allWarga.collectAsStateWithLifecycle()

    val canManage = currentRole.canManageIuran()
    val isWargaOnly = currentRole == UserRole.WARGA

    // Role-based visibility: warga sees only their own iuran, pengurus sees all
    val displayList = if (isWargaOnly && currentUser?.wargaId != null) {
        allIuran.filter { it.wargaId == currentUser?.wargaId }
    } else {
        allIuran
    }

    var selectedStatusFilter by remember { mutableStateOf("Semua") } // Semua, Lunas, Belum Lunas
    var searchQuery by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }

    val filteredList = displayList.filter { item ->
        val matchesSearch = item.namaWarga.contains(searchQuery, ignoreCase = true) ||
                item.nomorRumah.contains(searchQuery, ignoreCase = true) ||
                item.jenisIuran.contains(searchQuery, ignoreCase = true)
        val matchesStatus = if (selectedStatusFilter == "Semua") true else item.status.equals(selectedStatusFilter, ignoreCase = true)
        matchesSearch && matchesStatus
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("iuran_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Info Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isWargaOnly) "Riwayat Iuran Saya" else "Pengelolaan Iuran Warga",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isWargaOnly) "Data pribadi untuk ${currentUser?.nama}" else "Pantauan setoran iuran warga RT 05",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Payment,
                                contentDescription = null,
                                tint = GreenAccent,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            // Ringkasan Iuran (3 cards)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "Sudah Bayar",
                        value = "${summary.totalSudahBayar} Warga",
                        icon = Icons.Default.CheckCircle,
                        iconColor = GreenAccent,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Belum Bayar",
                        value = "${summary.totalBelumBayar} Warga",
                        icon = Icons.Default.HourglassEmpty,
                        iconColor = ExpenseRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                StatCard(
                    title = "Total Iuran Terkumpul",
                    value = FormatUtils.formatRupiah(summary.totalUangTerkumpul),
                    icon = Icons.Default.Payment,
                    iconColor = NavyPrimary,
                    subtitle = "Periode Oktober 2026",
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Search & Filter (for pengurus or warga)
            if (!isWargaOnly) {
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Cari warga atau blok rumah...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("Semua", "Lunas", "Belum Lunas")) { st ->
                        FilterChip(
                            selected = selectedStatusFilter == st,
                            onClick = { selectedStatusFilter = st },
                            label = { Text(st) }
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Daftar Tagihan Iuran (${filteredList.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (isWargaOnly) {
                        Text(
                            text = "Privasi Terjaga",
                            fontSize = 11.sp,
                            color = GreenAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            items(filteredList) { item ->
                IuranItemCard(
                    iuran = item,
                    canManage = canManage,
                    onToggleStatus = { newLunas ->
                        viewModel.updateIuranPaymentStatus(item, newLunas)
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // FAB Tambah Tagihan Iuran untuk Pengurus
        if (canManage) {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = GreenAccent,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_iuran_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Buat Tagihan Iuran")
            }
        }
    }

    if (showCreateDialog) {
        CreateIuranDialog(
            wargaList = wargaList,
            onDismiss = { showCreateDialog = false },
            onSave = { warga, jenisIuran, nominal, bulan ->
                val newIuran = IuranEntity(
                    id = 0,
                    wargaId = warga.id,
                    namaWarga = warga.nama,
                    nomorRumah = warga.nomorRumah,
                    bulan = bulan,
                    jenisIuran = jenisIuran,
                    nominal = nominal,
                    status = "Belum Lunas"
                )
                viewModel.addIuran(newIuran)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun IuranItemCard(
    iuran: IuranEntity,
    canManage: Boolean,
    onToggleStatus: (Boolean) -> Unit
) {
    val isLunas = iuran.status.equals("Lunas", ignoreCase = true)
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (isLunas) GreenAccent.copy(alpha = 0.15f) else ExpenseRed.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isLunas) Icons.Default.CheckCircle else Icons.Default.HourglassEmpty,
                    contentDescription = iuran.status,
                    tint = if (isLunas) GreenAccent else ExpenseRed,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = iuran.namaWarga,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${iuran.nomorRumah} • ${iuran.jenisIuran}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isLunas) "Dibayar: ${iuran.tanggalBayar ?: "-"}" else "Periode: ${iuran.bulan}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = FormatUtils.formatRupiah(iuran.nominal),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isLunas) GreenAccent else NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                StatusPill(text = iuran.status, statusType = iuran.status)

                if (canManage) {
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = { onToggleStatus(!isLunas) },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                    ) {
                        Text(
                            text = if (isLunas) "Batal Lunas" else "Tandai Lunas",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLunas) ExpenseRed else GreenAccent
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CreateIuranDialog(
    wargaList: List<WargaEntity>,
    onDismiss: () -> Unit,
    onSave: (warga: WargaEntity, jenisIuran: String, nominal: Long, bulan: String) -> Unit
) {
    var selectedWarga by remember { mutableStateOf(wargaList.firstOrNull()) }
    var jenisIuran by remember { mutableStateOf("Iuran Bulanan") }
    var nominalText by remember { mutableStateOf("100000") }
    var bulan by remember { mutableStateOf("Oktober 2026") }

    val jenisList = listOf("Iuran Bulanan", "Kebersihan", "Keamanan", "Iuran Khusus", "Iuran Kegiatan")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Buat Tagihan Iuran Warga", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(text = "Pilih Warga:", fontSize = 12.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(wargaList) { w ->
                            FilterChip(
                                selected = selectedWarga?.id == w.id,
                                onClick = { selectedWarga = w },
                                label = { Text("${w.nama} (${w.nomorRumah})") }
                            )
                        }
                    }
                }

                item {
                    Text(text = "Jenis Iuran:", fontSize = 12.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(jenisList) { j ->
                            FilterChip(
                                selected = jenisIuran == j,
                                onClick = { jenisIuran = j },
                                label = { Text(j) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = nominalText,
                        onValueChange = { if (it.all { c -> c.isDigit() }) nominalText = it },
                        label = { Text("Nominal (Rp)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = bulan,
                        onValueChange = { bulan = it },
                        label = { Text("Periode Bulan") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val w = selectedWarga
                    val nom = nominalText.toLongOrNull() ?: 0L
                    if (w != null && nom > 0L) {
                        onSave(w, jenisIuran, nom, bulan)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
