package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PengumumanEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.StatusPill
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel

@Composable
fun PengumumanScreen(
    viewModel: RTViewModel
) {
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val pengumumanList by viewModel.allPengumuman.collectAsStateWithLifecycle()

    val canManage = currentRole.canManagePengumuman()

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedPengumumanDetail by remember { mutableStateOf<PengumumanEntity?>(null) }
    var pengumumanToDelete by remember { mutableStateOf<PengumumanEntity?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("pengumuman_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Papan Pengumuman Resmi",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Warta & Informasi Terpadu Lingkungan RT 05",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = GreenAccent,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            items(pengumumanList) { p ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPengumumanDetail = p }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusPill(text = p.status, statusType = p.status)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = p.tanggal,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                                if (canManage) {
                                    IconButton(
                                        onClick = { pengumumanToDelete = p },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Hapus",
                                            tint = ExpenseRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = p.judul,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = p.isi,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                            lineHeight = 18.sp
                        )

                        if (p.lampiran.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = NavyPrimary.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AttachFile,
                                        contentDescription = null,
                                        tint = NavyPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Lampiran: ${p.lampiran}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NavyPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Oleh: ${p.penanggungJawab}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        if (canManage) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = NavyPrimary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_pengumuman_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Buat Pengumuman")
            }
        }
    }

    // Detail Dialog
    if (selectedPengumumanDetail != null) {
        val p = selectedPengumumanDetail!!
        AlertDialog(
            onDismissRequest = { selectedPengumumanDetail = null },
            title = {
                Text(text = p.judul, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(text = p.status, statusType = p.status)
                        Text(text = p.tanggal, fontSize = 12.sp, color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = p.isi, fontSize = 14.sp, lineHeight = 20.sp)
                    if (p.lampiran.isNotBlank()) {
                        Text(text = "Lampiran Dokumen: ${p.lampiran}", fontSize = 12.sp, color = NavyPrimary, fontWeight = FontWeight.SemiBold)
                    }
                    Text(text = "Diterbitkan oleh: ${p.penanggungJawab}", fontSize = 11.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPengumumanDetail = null }) {
                    Text("Tutup")
                }
            }
        )
    }

    if (showAddDialog) {
        PengumumanFormDialog(
            onDismiss = { showAddDialog = false },
            onSave = { judul, isi, status, lampiran ->
                viewModel.addPengumuman(judul, isi, status, lampiran)
                showAddDialog = false
            }
        )
    }

    if (pengumumanToDelete != null) {
        val toDel = pengumumanToDelete!!
        ConfirmDeleteDialog(
            title = "Hapus Pengumuman",
            message = "Apakah Anda yakin ingin menghapus pengumuman '${toDel.judul}'?",
            onConfirm = {
                viewModel.deletePengumuman(toDel)
                pengumumanToDelete = null
            },
            onDismiss = { pengumumanToDelete = null }
        )
    }
}

@Composable
fun PengumumanFormDialog(
    onDismiss: () -> Unit,
    onSave: (judul: String, isi: String, status: String, lampiran: String) -> Unit
) {
    var judul by remember { mutableStateOf("") }
    var isi by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Penting") }
    var lampiran by remember { mutableStateOf("") }

    val statusList = listOf("Penting", "Biasa", "Mendesak")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Terbitkan Pengumuman Baru", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = judul,
                    onValueChange = { judul = it },
                    label = { Text("Judul Pengumuman*") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text(text = "Tingkat Urgensi:", fontSize = 12.sp, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(statusList) { st ->
                        FilterChip(
                            selected = status == st,
                            onClick = { status = st },
                            label = { Text(st) }
                        )
                    }
                }

                OutlinedTextField(
                    value = isi,
                    onValueChange = { isi = it },
                    label = { Text("Isi Pengumuman*") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 5
                )

                OutlinedTextField(
                    value = lampiran,
                    onValueChange = { lampiran = it },
                    label = { Text("Nama Berkas Lampiran (Opsional)") },
                    placeholder = { Text("e.g. Edaran_RT05.pdf") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (judul.isNotBlank() && isi.isNotBlank()) {
                        onSave(judul, isi, status, lampiran)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Text("Terbitkan")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
