package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.KegiatanEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.StatusPill
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel
import com.example.util.FormatUtils

@Composable
fun KegiatanScreen(
    viewModel: RTViewModel
) {
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val kegiatanList by viewModel.allKegiatan.collectAsStateWithLifecycle()

    val canManage = currentRole.canManageKegiatan()

    var selectedStatusFilter by remember { mutableStateOf("Semua") }
    var selectedKegiatanDetail by remember { mutableStateOf<KegiatanEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var kegiatanToDelete by remember { mutableStateOf<KegiatanEntity?>(null) }

    val filterOptions = listOf("Semua", "Akan Datang", "Selesai")

    val filteredList = kegiatanList.filter {
        if (selectedStatusFilter == "Semua") true
        else it.status.equals(selectedStatusFilter, ignoreCase = true)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("kegiatan_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Banner
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Agenda & Kegiatan RT 05",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Membangun kekeluargaan dan lingkungan asri",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Event,
                                contentDescription = null,
                                tint = GreenAccent,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            // Filter Tabs
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filterOptions) { opt ->
                        FilterChip(
                            selected = selectedStatusFilter == opt,
                            onClick = { selectedStatusFilter = opt },
                            label = { Text(opt) }
                        )
                    }
                }
            }

            // List of Kegiatan
            items(filteredList) { k ->
                KegiatanCard(
                    kegiatan = k,
                    canManage = canManage,
                    onClick = { selectedKegiatanDetail = k },
                    onRsvp = { viewModel.rsvpKegiatan(k) },
                    onDelete = { kegiatanToDelete = k }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        if (canManage) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = NavyPrimary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_kegiatan_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Kegiatan")
            }
        }
    }

    // Detail Dialog
    if (selectedKegiatanDetail != null) {
        val k = selectedKegiatanDetail!!
        AlertDialog(
            onDismissRequest = { selectedKegiatanDetail = null },
            title = {
                Text(text = k.namaKegiatan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(text = k.status, statusType = k.status)
                        Text(text = "${k.rsvpCount} Warga Hadir/RSVP", fontSize = 12.sp, color = GreenAccent, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "📅 Tanggal: ${k.tanggal}", fontSize = 13.sp)
                    Text(text = "⏰ Waktu: ${k.waktu}", fontSize = 13.sp)
                    Text(text = "📍 Lokasi: ${k.lokasi}", fontSize = 13.sp)
                    Text(text = "👤 Penanggung Jawab: ${k.penanggungJawab}", fontSize = 13.sp)
                    Text(text = "💰 Anggaran RT: ${FormatUtils.formatRupiah(k.anggaran)}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Deskripsi Kegiatan:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text(text = k.deskripsi, fontSize = 13.sp, lineHeight = 18.sp)
                }
            },
            confirmButton = {
                if (k.status == "Akan Datang") {
                    Button(
                        onClick = {
                            viewModel.rsvpKegiatan(k)
                            selectedKegiatanDetail = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
                    ) {
                        Text("Konfirmasi Hadir (RSVP)")
                    }
                } else {
                    TextButton(onClick = { selectedKegiatanDetail = null }) {
                        Text("Tutup")
                    }
                }
            },
            dismissButton = {
                if (k.status == "Akan Datang") {
                    TextButton(onClick = { selectedKegiatanDetail = null }) {
                        Text("Tutup")
                    }
                }
            }
        )
    }

    if (showAddDialog) {
        KegiatanFormDialog(
            onDismiss = { showAddDialog = false },
            onSave = { kegiatan ->
                viewModel.addKegiatan(kegiatan)
                showAddDialog = false
            }
        )
    }

    if (kegiatanToDelete != null) {
        val toDel = kegiatanToDelete!!
        ConfirmDeleteDialog(
            title = "Hapus Kegiatan",
            message = "Apakah Anda yakin ingin menghapus agenda '${toDel.namaKegiatan}'?",
            onConfirm = {
                viewModel.deleteKegiatan(toDel)
                kegiatanToDelete = null
            },
            onDismiss = { kegiatanToDelete = null }
        )
    }
}

@Composable
fun KegiatanCard(
    kegiatan: KegiatanEntity,
    canManage: Boolean,
    onClick: () -> Unit,
    onRsvp: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(text = kegiatan.status, statusType = kegiatan.status)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${kegiatan.rsvpCount} Warga Terdaftar",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GreenAccent
                    )
                    if (canManage) {
                        IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Hapus",
                                tint = ExpenseRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = kegiatan.namaKegiatan,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Event, contentDescription = null, tint = NavyLight, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "${kegiatan.tanggal} • ${kegiatan.waktu}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = kegiatan.lokasi, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = kegiatan.deskripsi,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 16.sp
            )

            if (kegiatan.status == "Akan Datang") {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onRsvp,
                        colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ikut Serta / Hadir", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun KegiatanFormDialog(
    onDismiss: () -> Unit,
    onSave: (KegiatanEntity) -> Unit
) {
    var namaKegiatan by remember { mutableStateOf("") }
    var tanggal by remember { mutableStateOf("20 Okt 2026") }
    var waktu by remember { mutableStateOf("08:00 - 11:00 WIB") }
    var lokasi by remember { mutableStateOf("Balai Warga RT 05") }
    var penanggungJawab by remember { mutableStateOf("Seksi Kegiatan RT") }
    var anggaranText by remember { mutableStateOf("300000") }
    var deskripsi by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Jadwalkan Kegiatan Baru", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = namaKegiatan,
                        onValueChange = { namaKegiatan = it },
                        label = { Text("Nama Kegiatan*") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = tanggal,
                            onValueChange = { tanggal = it },
                            label = { Text("Tanggal") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = waktu,
                            onValueChange = { waktu = it },
                            label = { Text("Waktu") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = lokasi,
                        onValueChange = { lokasi = it },
                        label = { Text("Lokasi Pelaksanaan") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = penanggungJawab,
                        onValueChange = { penanggungJawab = it },
                        label = { Text("Penanggung Jawab") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = anggaranText,
                        onValueChange = { if (it.all { c -> c.isDigit() }) anggaranText = it },
                        label = { Text("Anggaran RT (Rp)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = deskripsi,
                        onValueChange = { deskripsi = it },
                        label = { Text("Deskripsi / Keterangan Kegiatan") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (namaKegiatan.isNotBlank()) {
                        val k = KegiatanEntity(
                            id = 0,
                            namaKegiatan = namaKegiatan,
                            tanggal = tanggal,
                            waktu = waktu,
                            lokasi = lokasi,
                            penanggungJawab = penanggungJawab,
                            anggaran = anggaranText.toLongOrNull() ?: 0L,
                            deskripsi = deskripsi.ifBlank { "Kegiatan kebersamaan warga RT 05." },
                            status = "Akan Datang",
                            rsvpCount = 1
                        )
                        onSave(k)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
