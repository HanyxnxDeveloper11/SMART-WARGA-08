package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector

enum class NavScreen(
    val title: String,
    val icon: ImageVector,
    val route: String
) {
    BERANDA("Beranda", Icons.Default.Home, "beranda"),
    WARGA("Data Warga", Icons.Default.People, "warga"),
    KAS("Transparansi Kas", Icons.Default.AccountBalanceWallet, "kas"),
    IURAN("Iuran Warga", Icons.Default.Payment, "iuran"),
    KEGIATAN("Kegiatan RT", Icons.Default.Event, "kegiatan"),
    PENGUMUMAN("Pengumuman", Icons.Default.Campaign, "pengumuman"),
    SURAT("Surat", Icons.Default.Assignment, "surat"),
    LAPORAN("Laporan", Icons.Default.BarChart, "laporan"),
    PROFIL("Profil", Icons.Default.Person, "profil")
}
