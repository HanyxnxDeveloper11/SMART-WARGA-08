package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SuratEntity
import com.example.data.model.UserRole
import com.example.data.model.WargaEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.StatusPill
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel
import com.example.util.FormatUtils

@Composable
fun SuratScreen(
    viewModel: RTViewModel
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val suratList by viewModel.allSurat.collectAsStateWithLifecycle()
    val wargaList by viewModel.allWarga.collectAsStateWithLifecycle()

    val canManage = currentRole.canManageSurat()
    val isWargaOnly = currentRole == UserRole.WARGA

    val displaySuratList = if (isWargaOnly && currentUser?.wargaId != null) {
        suratList.filter { it.wargaId == currentUser?.wargaId }
    } else {
        suratList
    }

    var showFormDialog by remember { mutableStateOf(false) }
    var selectedSuratPreview by remember { mutableStateOf<SuratEntity?>(null) }
    var suratToDelete by remember { mutableStateOf<SuratEntity?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("surat_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isWargaOnly) "Permohonan Surat Saya" else "Administrasi Surat Warga",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Penerbitan surat pengantar, domisili, dan SKU terstandar",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Assignment,
                                contentDescription = null,
                                tint = GreenAccent,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Daftar Surat Pengajuan (${displaySuratList.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (canManage) "Pengurus: Otorisasi & Cetak" else "Warga: Ajukan Permohonan",
                        fontSize = 11.sp,
                        color = if (canManage) GreenAccent else NavyPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            items(displaySuratList) { s ->
                SuratItemCard(
                    surat = s,
                    canManage = canManage,
                    onClick = { selectedSuratPreview = s },
                    onApprove = { viewModel.updateSuratStatus(s, "Disetujui") },
                    onReject = { viewModel.updateSuratStatus(s, "Ditolak") },
                    onDelete = { suratToDelete = s }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Floating Action Button to create/request a letter
        FloatingActionButton(
            onClick = { showFormDialog = true },
            containerColor = NavyPrimary,
            contentColor = Color.White,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_surat_fab")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Buat Pengajuan Surat")
        }
    }

    // Official Letter Preview Dialog
    if (selectedSuratPreview != null) {
        val s = selectedSuratPreview!!
        AlertDialog(
            onDismissRequest = { selectedSuratPreview = null },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Preview Surat Resmi", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    StatusPill(text = s.status, statusType = s.status)
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFCFDFE))
                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    // Kop Surat RT / RW
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "RUKUN TETANGGA 05 / RUKUN WARGA 08",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                color = NavyPrimary
                            )
                            Text(
                                text = "KELURAHAN SUKAMAJU, KECAMATAN CILODONG",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "KOTA DEPOK - JAWA BARAT",
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            HorizontalDivider(thickness = 2.dp, color = Color.Black)
                            HorizontalDivider(thickness = 0.5.dp, color = Color.Black, modifier = Modifier.padding(top = 1.dp))
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = s.jenisSurat.uppercase(),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline
                            )
                            Text(
                                text = "Nomor: ${s.nomorSurat}",
                                fontSize = 10.sp,
                                color = Color.DarkGray
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Yang bertanda tangan di bawah ini Pengurus RT 05 / RW 08 Kelurahan Sukamaju, menerangkan dengan sesungguhnya bahwa:",
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            OfficialField("Nama Lengkap", s.namaWarga)
                            OfficialField("NIK", s.nikWarga)
                            OfficialField("Alamat / Rumah", "${s.nomorRumah}, RT 05 / RW 08")
                            OfficialField("Keperluan", s.keperluan)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (s.keterangan.isNotBlank())
                                "Keterangan: ${s.keterangan} Orang tersebut di atas adalah benar warga yang tercatat pada lingkungan kami."
                            else
                                "Orang tersebut di atas adalah benar warga yang berkelakuan baik dan berdomisili di lingkungan RT 05 / RW 08.",
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Depok, ${s.tanggal}", fontSize = 10.sp)
                                Text(text = "Ketua RT 05 Sukamaju,", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(28.dp))
                                Text(text = "( H. Bambang Sutrisno )", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val shareIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    """
                                    *SURAT RESMI RT 05 / RW 08 SUKAMAJU*
                                    Jenis: ${s.jenisSurat}
                                    Nomor: ${s.nomorSurat}
                                    Tanggal: ${s.tanggal}
                                    
                                    Menerangkan bahwa:
                                    Nama: ${s.namaWarga}
                                    NIK: ${s.nikWarga}
                                    Alamat: ${s.nomorRumah}
                                    Keperluan: ${s.keperluan}
                                    Status: ${s.status}
                                    
                                    Pengurus RT 05 / RW 08
                                    Kel. Sukamaju, Kec. Cilodong, Kota Depok
                                    """.trimIndent()
                                )
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Bagikan / Cetak Surat Resmi"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Cetak / Bagikan")
                    }
                    TextButton(onClick = { selectedSuratPreview = null }) {
                        Text("Tutup")
                    }
                }
            }
        )
    }

    // Form Pengajuan Surat
    if (showFormDialog) {
        SuratFormDialog(
            wargaList = wargaList,
            currentUserWargaId = currentUser?.wargaId,
            onDismiss = { showFormDialog = false },
            onSubmit = { warga, jenisSurat, keperluan, keterangan ->
                viewModel.submitSuratRequest(jenisSurat, warga, keperluan, keterangan)
                showFormDialog = false
            }
        )
    }

    // Delete confirmation
    if (suratToDelete != null) {
        val toDel = suratToDelete!!
        ConfirmDeleteDialog(
            title = "Hapus Surat",
            message = "Apakah Anda yakin ingin menghapus data surat ${toDel.nomorSurat}?",
            onConfirm = {
                viewModel.deleteSurat(toDel)
                suratToDelete = null
            },
            onDismiss = { suratToDelete = null }
        )
    }
}

@Composable
fun SuratItemCard(
    surat: SuratEntity,
    canManage: Boolean,
    onClick: () -> Unit,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(text = surat.status, statusType = surat.status)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = surat.tanggal,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    if (canManage) {
                        IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Hapus",
                                tint = ExpenseRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = surat.jenisSurat,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "Pemohon: ${surat.namaWarga} (${surat.nomorRumah})",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "Keperluan: ${surat.keperluan}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "No: ${surat.nomorSurat}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NavyLight
                )

                if (canManage && surat.status == "Menunggu") {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = onApprove,
                            colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Setujui", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = onReject,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Tolak", fontSize = 11.sp, color = ExpenseRed)
                        }
                    }
                } else {
                    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Lihat Format Cetak", fontSize = 11.sp, color = NavyPrimary)
                    }
                }
            }
        }
    }
}

@Composable
fun OfficialField(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(text = "$label", fontSize = 11.sp, modifier = Modifier.width(90.dp), color = Color.DarkGray)
        Text(text = ": $value", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SuratFormDialog(
    wargaList: List<WargaEntity>,
    currentUserWargaId: String?,
    onDismiss: () -> Unit,
    onSubmit: (warga: WargaEntity, jenisSurat: String, keperluan: String, keterangan: String) -> Unit
) {
    var selectedWarga by remember {
        mutableStateOf(wargaList.find { it.id == currentUserWargaId } ?: wargaList.firstOrNull())
    }
    var selectedJenis by remember { mutableStateOf("Surat Pengantar RT/RW") }
    var keperluan by remember { mutableStateOf("") }
    var keterangan by remember { mutableStateOf("") }

    val jenisList = listOf(
        "Surat Pengantar RT/RW",
        "Surat Keterangan Domisili",
        "Surat Keterangan Usaha (SKU)",
        "Surat Keterangan Tidak Mampu (SKTM)",
        "Surat Pengantar Administrasi KTP/KK",
        "Surat Izin Keramaian"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengajuan Surat Warga", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(text = "Pilih Warga Pemohon:", fontSize = 12.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(wargaList) { w ->
                            FilterChip(
                                selected = selectedWarga?.id == w.id,
                                onClick = { selectedWarga = w },
                                label = { Text("${w.nama} (${w.nomorRumah})") }
                            )
                        }
                    }
                }

                item {
                    Text(text = "Jenis Surat:", fontSize = 12.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(jenisList) { j ->
                            FilterChip(
                                selected = selectedJenis == j,
                                onClick = { selectedJenis = j },
                                label = { Text(j) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = keperluan,
                        onValueChange = { keperluan = it },
                        label = { Text("Keperluan Pembuatan Surat*") },
                        placeholder = { Text("contoh: Pengantar pembuatan SKCK di Polsek") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = keterangan,
                        onValueChange = { keterangan = it },
                        label = { Text("Keterangan Tambahan (Opsional)") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val w = selectedWarga
                    if (w != null && keperluan.isNotBlank()) {
                        onSubmit(w, selectedJenis, keperluan, keterangan)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Text("Ajukan Permohonan")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
