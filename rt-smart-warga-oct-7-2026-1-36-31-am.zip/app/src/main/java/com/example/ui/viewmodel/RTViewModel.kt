package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.IuranEntity
import com.example.data.model.KasEntity
import com.example.data.model.KegiatanEntity
import com.example.data.model.PengumumanEntity
import com.example.data.model.SuratEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.data.model.WargaEntity
import com.example.data.repository.RTRepository
import com.example.ui.navigation.NavScreen
import com.example.util.FormatUtils
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class KasSummary(
    val saldo: Long = 0L,
    val totalPemasukan: Long = 0L,
    val totalPengeluaran: Long = 0L
)

data class DemografiSummary(
    val totalWarga: Int = 0,
    val totalKk: Int = 0,
    val totalLakiLaki: Int = 0,
    val totalPerempuan: Int = 0,
    val totalAnak: Int = 0,
    val totalRemaja: Int = 0,
    val totalDewasa: Int = 0,
    val totalLansia: Int = 0
)

data class IuranSummary(
    val totalSudahBayar: Int = 0,
    val totalBelumBayar: Int = 0,
    val totalUangTerkumpul: Long = 0L
)

class RTViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RTRepository

    init {
        val database = AppDatabase.getInstance(application)
        repository = RTRepository(database)
        viewModelScope.launch {
            repository.ensureDataPopulated()
        }
    }

    // Navigation State
    private val _currentScreen = MutableStateFlow(NavScreen.BERANDA)
    val currentScreen: StateFlow<NavScreen> = _currentScreen.asStateFlow()

    // Screen Backstack for system back button
    private val screenStack = mutableListOf(NavScreen.BERANDA)

    fun navigateTo(screen: NavScreen) {
        if (_currentScreen.value != screen) {
            screenStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun handleBackPress(): Boolean {
        return if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.size - 1)
            _currentScreen.value = screenStack.last()
            true
        } else {
            false
        }
    }

    // Snack / Notification messages
    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    fun showMessage(msg: String) {
        viewModelScope.launch {
            _toastEvent.emit(msg)
        }
    }

    // Active User State
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    val currentRole: StateFlow<UserRole> = _currentUser.combine(MutableStateFlow(Unit)) { user, _ ->
        if (user != null) {
            try {
                UserRole.valueOf(user.role)
            } catch (e: Exception) {
                UserRole.WARGA
            }
        } else {
            UserRole.ADMIN_KETUA_RT
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, UserRole.ADMIN_KETUA_RT)

    // Data Flows from Repository
    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWarga: StateFlow<List<WargaEntity>> = repository.allWarga
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allKas: StateFlow<List<KasEntity>> = repository.allKas
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allIuran: StateFlow<List<IuranEntity>> = repository.allIuran
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allKegiatan: StateFlow<List<KegiatanEntity>> = repository.allKegiatan
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPengumuman: StateFlow<List<PengumumanEntity>> = repository.allPengumuman
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSurat: StateFlow<List<SuratEntity>> = repository.allSurat
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Set default active user to Ketua RT initially
        viewModelScope.launch {
            allUsers.collect { users ->
                if (_currentUser.value == null && users.isNotEmpty()) {
                    _currentUser.value = users.first()
                }
            }
        }
    }

    fun switchUser(user: UserEntity) {
        _currentUser.value = user
        showMessage("Beralih peran sebagai: ${user.nama} (${UserRole.valueOf(user.role).label})")
    }

    // Calculations
    val kasSummary: StateFlow<KasSummary> = allKas.combine(MutableStateFlow(Unit)) { list, _ ->
        var pemasukan = 0L
        var pengeluaran = 0L
        list.forEach { kas ->
            if (kas.jenis.equals("Pemasukan", ignoreCase = true)) {
                pemasukan += kas.nominal
            } else {
                pengeluaran += kas.nominal
            }
        }
        KasSummary(
            saldo = pemasukan - pengeluaran,
            totalPemasukan = pemasukan,
            totalPengeluaran = pengeluaran
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), KasSummary())

    val demografiSummary: StateFlow<DemografiSummary> = allWarga.combine(MutableStateFlow(Unit)) { list, _ ->
        val kkSet = list.map { it.noKk }.toSet()
        val laki = list.count { it.jenisKelamin.contains("Laki", ignoreCase = true) }
        val perempuan = list.count { it.jenisKelamin.contains("Perempuan", ignoreCase = true) }

        // Category by birth year or dummy estimation
        val anak = list.count { it.pekerjaan.contains("Pelajar", ignoreCase = true) || it.statusPerkawinan.contains("Belum", ignoreCase = true) && it.status == "Kost" }
        val lansia = list.count { it.pekerjaan.contains("Pensiunan", ignoreCase = true) }
        val dewasa = list.size - anak - lansia

        DemografiSummary(
            totalWarga = list.size,
            totalKk = kkSet.size,
            totalLakiLaki = laki,
            totalPerempuan = perempuan,
            totalAnak = if (anak < 1) 2 else anak,
            totalRemaja = 3,
            totalDewasa = if (dewasa <= 0) 5 else dewasa,
            totalLansia = if (lansia < 1) 2 else lansia
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DemografiSummary())

    val iuranSummary: StateFlow<IuranSummary> = allIuran.combine(MutableStateFlow(Unit)) { list, _ ->
        val lunas = list.count { it.status.equals("Lunas", ignoreCase = true) }
        val belum = list.count { it.status.equals("Belum Lunas", ignoreCase = true) }
        val uang = list.filter { it.status.equals("Lunas", ignoreCase = true) }.sumOf { it.nominal }
        IuranSummary(
            totalSudahBayar = lunas,
            totalBelumBayar = belum,
            totalUangTerkumpul = uang
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), IuranSummary())

    // Warga CRUD
    fun addWarga(warga: WargaEntity) {
        viewModelScope.launch {
            repository.insertWarga(warga)
            showMessage("Data warga ${warga.nama} berhasil ditambahkan.")
        }
    }

    fun updateWarga(warga: WargaEntity) {
        viewModelScope.launch {
            repository.updateWarga(warga)
            showMessage("Data warga ${warga.nama} berhasil diperbarui.")
        }
    }

    fun deleteWarga(warga: WargaEntity) {
        viewModelScope.launch {
            repository.deleteWarga(warga.id)
            showMessage("Data warga ${warga.nama} berhasil dihapus.")
        }
    }

    // Kas CRUD
    fun addKas(
        jenis: String,
        kategori: String,
        keterangan: String,
        nominal: Long,
        bukti: String
    ) {
        viewModelScope.launch {
            val user = _currentUser.value
            val kas = KasEntity(
                tanggal = FormatUtils.getCurrentDateFormatted(),
                jenis = jenis,
                kategori = kategori,
                keterangan = keterangan,
                nominal = nominal,
                bukti = bukti.ifBlank { "Tercatat di Sistem" },
                dicatatOleh = user?.nama ?: "Pengurus RT"
            )
            repository.insertKas(kas)
            showMessage("Transaksi $jenis sebesar ${FormatUtils.formatRupiah(nominal)} berhasil dicatat.")
        }
    }

    fun deleteKas(kas: KasEntity) {
        viewModelScope.launch {
            repository.deleteKas(kas.id)
            showMessage("Transaksi kas berhasil dihapus.")
        }
    }

    // Iuran CRUD
    fun addIuran(iuran: IuranEntity) {
        viewModelScope.launch {
            repository.insertIuran(iuran)
            showMessage("Tagihan iuran untuk ${iuran.namaWarga} dibuat.")
        }
    }

    fun updateIuranPaymentStatus(iuran: IuranEntity, isLunas: Boolean) {
        viewModelScope.launch {
            val status = if (isLunas) "Lunas" else "Belum Lunas"
            val tgl = if (isLunas) FormatUtils.getCurrentDateFormatted() else null
            repository.updateIuranStatus(iuran.id, status, tgl)
            showMessage("Status iuran ${iuran.namaWarga} diperbarui menjadi $status.")
        }
    }

    // Kegiatan CRUD
    fun addKegiatan(kegiatan: KegiatanEntity) {
        viewModelScope.launch {
            repository.insertKegiatan(kegiatan)
            showMessage("Kegiatan '${kegiatan.namaKegiatan}' berhasil dijadwalkan.")
        }
    }

    fun rsvpKegiatan(kegiatan: KegiatanEntity) {
        viewModelScope.launch {
            repository.incrementRsvp(kegiatan.id)
            showMessage("Terima kasih! Anda telah terdaftar hadir di '${kegiatan.namaKegiatan}'.")
        }
    }

    fun deleteKegiatan(kegiatan: KegiatanEntity) {
        viewModelScope.launch {
            repository.deleteKegiatan(kegiatan.id)
            showMessage("Kegiatan berhasil dihapus.")
        }
    }

    // Pengumuman CRUD
    fun addPengumuman(judul: String, isi: String, status: String, lampiran: String = "") {
        viewModelScope.launch {
            val user = _currentUser.value
            val p = PengumumanEntity(
                judul = judul,
                isi = isi,
                tanggal = FormatUtils.getCurrentDateFormatted(),
                lampiran = lampiran,
                status = status,
                penanggungJawab = user?.nama ?: "Pengurus RT 05"
            )
            repository.insertPengumuman(p)
            showMessage("Pengumuman berhasil diterbitkan.")
        }
    }

    fun deletePengumuman(pengumuman: PengumumanEntity) {
        viewModelScope.launch {
            repository.deletePengumuman(pengumuman.id)
            showMessage("Pengumuman dihapus.")
        }
    }

    // Surat CRUD
    fun submitSuratRequest(
        jenisSurat: String,
        warga: WargaEntity,
        keperluan: String,
        keterangan: String = ""
    ) {
        viewModelScope.launch {
            val count = repository.allSurat.stateIn(viewModelScope).value.size
            val noSurat = FormatUtils.generateNomorSurat(count)
            val surat = SuratEntity(
                jenisSurat = jenisSurat,
                wargaId = warga.id,
                namaWarga = warga.nama,
                nikWarga = warga.nik,
                nomorRumah = warga.nomorRumah,
                nomorSurat = noSurat,
                tanggal = FormatUtils.getCurrentDateFormatted(),
                keperluan = keperluan,
                keterangan = keterangan,
                status = "Menunggu"
            )
            repository.insertSurat(surat)
            showMessage("Permohonan $jenisSurat berhasil diajukan.")
        }
    }

    fun updateSuratStatus(surat: SuratEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateSuratStatus(surat.id, newStatus)
            showMessage("Surat ${surat.nomorSurat} status diubah ke $newStatus.")
        }
    }

    fun deleteSurat(surat: SuratEntity) {
        viewModelScope.launch {
            repository.deleteSurat(surat.id)
            showMessage("Data surat dihapus.")
        }
    }
}
