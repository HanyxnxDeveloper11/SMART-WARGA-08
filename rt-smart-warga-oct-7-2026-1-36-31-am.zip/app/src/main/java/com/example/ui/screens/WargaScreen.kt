package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.WargaEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.StatCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel
import com.example.util.FormatUtils

@Composable
fun WargaScreen(
    viewModel: RTViewModel
) {
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val wargaList by viewModel.allWarga.collectAsStateWithLifecycle()
    val demografi by viewModel.demografiSummary.collectAsStateWithLifecycle()

    val canManage = currentRole.canManageWarga()
    val canSeeFullDetails = currentRole.canSeeFullResidentDetails()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterStatus by remember { mutableStateOf("Semua") }

    var selectedWargaDetail by remember { mutableStateOf<WargaEntity?>(null) }
    var wargaToEdit by remember { mutableStateOf<WargaEntity?>(null) }
    var wargaToDelete by remember { mutableStateOf<WargaEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val filterOptions = listOf("Semua", "Tetap", "Kontrak", "Kost", "Pindah")

    val filteredList = wargaList.filter { w ->
        val matchesSearch = w.nama.contains(searchQuery, ignoreCase = true) ||
                w.nomorRumah.contains(searchQuery, ignoreCase = true) ||
                w.pekerjaan.contains(searchQuery, ignoreCase = true)
        val matchesStatus = if (selectedFilterStatus == "Semua") true else w.status.equals(selectedFilterStatus, ignoreCase = true)
        matchesSearch && matchesStatus
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("warga_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card with Privacy Notice
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (canSeeFullDetails) NavyPrimary else Color(0xFF1E293B)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Database Penduduk RT 05",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (canSeeFullDetails)
                                        "Mode Pengurus: Akses data lengkap & NIK aktif"
                                    else
                                        "Mode Warga: Perlindungan Privasi Data Aktif",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            }
                            Icon(
                                imageVector = if (canSeeFullDetails) Icons.Default.Shield else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (canSeeFullDetails) GreenAccent else WarningAmber,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        if (!canSeeFullDetails) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = Color.White.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "Sesuai regulasi privasi warga, NIK, No. KK dan No. HP disensor demi keamanan identitas warga.",
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(8.dp),
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            // Demografi Warga Statistics (Accessible to all warga)
            item {
                Text(
                    text = "Statistik Demografi",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "Total Penduduk",
                        value = "${demografi.totalWarga}",
                        icon = Icons.Default.People,
                        iconColor = NavyPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Kepala Keluarga",
                        value = "${demografi.totalKk}",
                        icon = Icons.Default.Home,
                        iconColor = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "Laki-laki",
                        value = "${demografi.totalLakiLaki}",
                        icon = Icons.Default.Male,
                        iconColor = Color(0xFF2563EB),
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Perempuan",
                        value = "${demografi.totalPerempuan}",
                        icon = Icons.Default.Female,
                        iconColor = Color(0xFFEC4899),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Age category demographic breakdown card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Kategori Usia Penduduk",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            DemografiAgePill("Anak-anak", "${demografi.totalAnak}", Color(0xFF10B981))
                            DemografiAgePill("Remaja", "${demografi.totalRemaja}", Color(0xFF0284C7))
                            DemografiAgePill("Dewasa", "${demografi.totalDewasa}", Color(0xFF8B5CF6))
                            DemografiAgePill("Lansia", "${demografi.totalLansia}", Color(0xFFF59E0B))
                        }
                    }
                }
            }

            // Search Bar & Filter Chips
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Cari warga (nama, blok rumah, pekerjaan)...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Cari")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_warga_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filterOptions) { status ->
                        FilterChip(
                            selected = selectedFilterStatus == status,
                            onClick = { selectedFilterStatus = status },
                            label = { Text(status) }
                        )
                    }
                }
            }

            item {
                Text(
                    text = "Daftar Warga (${filteredList.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            items(filteredList) { warga ->
                WargaItemCard(
                    warga = warga,
                    canSeeFullDetails = canSeeFullDetails,
                    canManage = canManage,
                    onClick = { selectedWargaDetail = warga },
                    onEdit = { wargaToEdit = warga },
                    onDelete = { wargaToDelete = warga }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Floating Action Button for Pengurus
        if (canManage) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = GreenAccent,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_warga_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Warga")
            }
        }
    }

    // Detail Dialog
    if (selectedWargaDetail != null) {
        val w = selectedWargaDetail!!
        AlertDialog(
            onDismissRequest = { selectedWargaDetail = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AvatarInitials(name = w.nama, size = 38)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = w.nama, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(text = "ID: ${w.id}", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailRow("Nomor Rumah", w.nomorRumah)
                    DetailRow("Status Kependudukan", w.status)
                    DetailRow("Jenis Kelamin", w.jenisKelamin)
                    DetailRow("Tempat, Tgl Lahir", "${w.tempatLahir}, ${w.tanggalLahir}")
                    DetailRow("Status Nikah", w.statusPerkawinan)
                    DetailRow("Pekerjaan", w.pekerjaan)

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Data Sensitif (Privasi):", fontWeight = FontWeight.Bold, fontSize = 12.sp)

                    DetailRow(
                        "NIK",
                        if (canSeeFullDetails) w.nik else FormatUtils.maskNik(w.nik),
                        isProtected = !canSeeFullDetails
                    )
                    DetailRow(
                        "Nomor KK",
                        if (canSeeFullDetails) w.noKk else FormatUtils.maskNoKk(w.noKk),
                        isProtected = !canSeeFullDetails
                    )
                    DetailRow(
                        "Nomor HP",
                        if (canSeeFullDetails) w.noHp else FormatUtils.maskPhone(w.noHp),
                        isProtected = !canSeeFullDetails
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedWargaDetail = null }) {
                    Text("Tutup")
                }
            }
        )
    }

    // Add or Edit Warga Dialog
    if (showAddDialog || wargaToEdit != null) {
        val editing = wargaToEdit
        WargaFormDialog(
            initial = editing,
            nextId = "W-${(wargaList.size + 1).toString().padStart(3, '0')}",
            onDismiss = {
                showAddDialog = false
                wargaToEdit = null
            },
            onSave = { savedWarga ->
                if (editing != null) {
                    viewModel.updateWarga(savedWarga)
                } else {
                    viewModel.addWarga(savedWarga)
                }
                showAddDialog = false
                wargaToEdit = null
            }
        )
    }

    // Confirm Delete Dialog
    if (wargaToDelete != null) {
        val toDel = wargaToDelete!!
        ConfirmDeleteDialog(
            title = "Hapus Data Warga",
            message = "Apakah Anda yakin ingin menghapus data warga '${toDel.nama}' (${toDel.nomorRumah})? Tindakan ini tidak dapat dibatalkan.",
            onConfirm = {
                viewModel.deleteWarga(toDel)
                wargaToDelete = null
            },
            onDismiss = { wargaToDelete = null }
        )
    }
}

@Composable
fun WargaItemCard(
    warga: WargaEntity,
    canSeeFullDetails: Boolean,
    canManage: Boolean,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AvatarInitials(name = warga.nama, size = 44)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = warga.nama,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${warga.nomorRumah} • ${warga.pekerjaan}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusPill(text = warga.status, statusType = warga.status)
                    Text(
                        text = if (canSeeFullDetails) warga.nik else "NIK: ${FormatUtils.maskNik(warga.nik)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            if (canManage) {
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit",
                        tint = NavyLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Hapus",
                        tint = ExpenseRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AvatarInitials(name: String, size: Int = 40) {
    val initials = name.split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .map { it.first().uppercase() }
        .joinToString("")

    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(NavyPrimary.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials.ifBlank { "W" },
            fontWeight = FontWeight.Bold,
            color = NavyPrimary,
            fontSize = (size / 2.6).sp
        )
    }
}

@Composable
fun DetailRow(label: String, value: String, isProtected: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = Color.Gray)
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isProtected) Color(0xFF0284C7) else Color.Unspecified
        )
    }
}

@Composable
fun DemografiAgePill(label: String, count: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = count, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = color)
        Text(text = label, fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun WargaFormDialog(
    initial: WargaEntity?,
    nextId: String,
    onDismiss: () -> Unit,
    onSave: (WargaEntity) -> Unit
) {
    var nama by remember { mutableStateOf(initial?.nama ?: "") }
    var nik by remember { mutableStateOf(initial?.nik ?: "") }
    var noKk by remember { mutableStateOf(initial?.noKk ?: "") }
    var jenisKelamin by remember { mutableStateOf(initial?.jenisKelamin ?: "Laki-laki") }
    var tempatLahir by remember { mutableStateOf(initial?.tempatLahir ?: "") }
    var tanggalLahir by remember { mutableStateOf(initial?.tanggalLahir ?: "") }
    var statusPerkawinan by remember { mutableStateOf(initial?.statusPerkawinan ?: "Kawin") }
    var pekerjaan by remember { mutableStateOf(initial?.pekerjaan ?: "") }
    var nomorRumah by remember { mutableStateOf(initial?.nomorRumah ?: "") }
    var noHp by remember { mutableStateOf(initial?.noHp ?: "") }
    var status by remember { mutableStateOf(initial?.status ?: "Tetap") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initial != null) "Edit Data Warga" else "Tambah Warga Baru",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = nama,
                        onValueChange = { nama = it },
                        label = { Text("Nama Lengkap*") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = nik,
                        onValueChange = { nik = it },
                        label = { Text("NIK (16 Digit)*") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = noKk,
                        onValueChange = { noKk = it },
                        label = { Text("Nomor Kartu Keluarga (KK)*") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = nomorRumah,
                        onValueChange = { nomorRumah = it },
                        label = { Text("Nomor Rumah (contoh: Blok B No. 12)*") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = noHp,
                        onValueChange = { noHp = it },
                        label = { Text("Nomor HP / WhatsApp") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = pekerjaan,
                        onValueChange = { pekerjaan = it },
                        label = { Text("Pekerjaan") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = tempatLahir,
                            onValueChange = { tempatLahir = it },
                            label = { Text("Tempat Lahir") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = tanggalLahir,
                            onValueChange = { tanggalLahir = it },
                            label = { Text("Tgl Lahir") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    Text(text = "Jenis Kelamin:", fontSize = 12.sp, color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = jenisKelamin == "Laki-laki",
                            onClick = { jenisKelamin = "Laki-laki" },
                            label = { Text("Laki-laki") }
                        )
                        FilterChip(
                            selected = jenisKelamin == "Perempuan",
                            onClick = { jenisKelamin = "Perempuan" },
                            label = { Text("Perempuan") }
                        )
                    }
                }
                item {
                    Text(text = "Status Kependudukan:", fontSize = 12.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf("Tetap", "Kontrak", "Kost", "Pindah")) { s ->
                            FilterChip(
                                selected = status == s,
                                onClick = { status = s },
                                label = { Text(s) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (nama.isNotBlank() && nomorRumah.isNotBlank()) {
                        val warga = WargaEntity(
                            id = initial?.id ?: nextId,
                            nama = nama,
                            nik = nik.ifBlank { "3276010000000000" },
                            noKk = noKk.ifBlank { "3276010000000000" },
                            jenisKelamin = jenisKelamin,
                            tempatLahir = tempatLahir.ifBlank { "Depok" },
                            tanggalLahir = tanggalLahir.ifBlank { "01 Jan 1990" },
                            statusPerkawinan = statusPerkawinan,
                            pekerjaan = pekerjaan.ifBlank { "Wiraswasta" },
                            nomorRumah = nomorRumah,
                            noHp = noHp.ifBlank { "081200000000" },
                            status = status
                        )
                        onSave(warga)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
