package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.ui.components.StatCard
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel
import com.example.util.FormatUtils

@Composable
fun LaporanScreen(
    viewModel: RTViewModel
) {
    val context = LocalContext.current
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val kasSummary by viewModel.kasSummary.collectAsStateWithLifecycle()
    val demografi by viewModel.demografiSummary.collectAsStateWithLifecycle()
    val iuranSummary by viewModel.iuranSummary.collectAsStateWithLifecycle()
    val kegiatanList by viewModel.allKegiatan.collectAsStateWithLifecycle()
    val kasList by viewModel.allKas.collectAsStateWithLifecycle()

    var selectedPeriode by remember { mutableStateOf("Bulan Ini (Oktober)") }
    val periodeOptions = listOf("Bulan Ini (Oktober)", "Triwulan III", "Tahun 2026")

    val totalAnggaranKegiatan = kegiatanList.sumOf { it.anggaran }

    fun generateLaporanText(): String {
        return """
        *REKAPITULASI LAPORAN ADMINISTRASI RT 05 / RW 08*
        Wilayah: Kel. Sukamaju, Kec. Cilodong, Kota Depok
        Periode: $selectedPeriode
        Tanggal Cetak: ${FormatUtils.getCurrentDateFormatted()}
        -------------------------------------------
        1. KEUANGAN & KAS RT:
        - Saldo Kas Bersih : ${FormatUtils.formatRupiah(kasSummary.saldo)}
        - Total Pemasukan  : ${FormatUtils.formatRupiah(kasSummary.totalPemasukan)}
        - Total Pengeluaran: ${FormatUtils.formatRupiah(kasSummary.totalPengeluaran)}
        
        2. PENERIMAAN IURAN:
        - Warga Sudah Lunas: ${iuranSummary.totalSudahBayar} Warga
        - Warga Belum Lunas: ${iuranSummary.totalBelumBayar} Warga
        - Total Terkumpul  : ${FormatUtils.formatRupiah(iuranSummary.totalUangTerkumpul)}
        
        3. DEMOGRAFI WARGA:
        - Total Penduduk   : ${demografi.totalWarga} Jiwa
        - Kepala Keluarga  : ${demografi.totalKk} KK
        - Laki-laki        : ${demografi.totalLakiLaki} Jiwa
        - Perempuan        : ${demografi.totalPerempuan} Jiwa
        
        4. KEGIATAN & AGENDA:
        - Total Agenda     : ${kegiatanList.size} Kegiatan
        - Realisasi Biaya  : ${FormatUtils.formatRupiah(totalAnggaranKegiatan)}
        -------------------------------------------
        Dilaporkan oleh: Pengurus RT 05 / RW 08
        """.trimIndent()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("laporan_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Laporan & Rekapitulasi RT",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Pertanggungjawaban berkala kas & kependudukan",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = null,
                            tint = GreenAccent,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }

        // Filter Periode
        item {
            Text(
                text = "Periode Laporan:",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(periodeOptions) { p ->
                    FilterChip(
                        selected = selectedPeriode == p,
                        onClick = { selectedPeriode = p },
                        label = { Text(p) }
                    )
                }
            }
        }

        // Section 1: Laporan Kas & Keuangan
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "1. Laporan Arus Kas RT",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                        Surface(
                            color = GreenAccent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Saldo: ${FormatUtils.formatRupiah(kasSummary.saldo)}",
                                color = Color(0xFF065F46),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    LaporanRow("Total Pemasukan Kas", FormatUtils.formatRupiah(kasSummary.totalPemasukan), GreenAccent)
                    LaporanRow("Total Pengeluaran Kas", FormatUtils.formatRupiah(kasSummary.totalPengeluaran), ExpenseRed)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    LaporanRow("Saldo Bersih Tersimpan", FormatUtils.formatRupiah(kasSummary.saldo), NavyPrimary, isBold = true)
                }
            }
        }

        // Section 2: Laporan Iuran Warga
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "2. Laporan Pembayaran Iuran",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    LaporanRow("Warga Sudah Melunasi", "${iuranSummary.totalSudahBayar} Warga", GreenAccent)
                    LaporanRow("Warga Belum Membayar", "${iuranSummary.totalBelumBayar} Warga", ExpenseRed)
                    LaporanRow("Tingkat Kepatuhan", "${(iuranSummary.totalSudahBayar * 100) / (iuranSummary.totalSudahBayar + iuranSummary.totalBelumBayar.coerceAtLeast(1))}%", NavyLight)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    LaporanRow("Total Uang Iuran Masuk", FormatUtils.formatRupiah(iuranSummary.totalUangTerkumpul), GreenAccent, isBold = true)
                }
            }
        }

        // Section 3: Laporan Demografi Kependudukan
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "3. Laporan Demografi Penduduk",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    LaporanRow("Total Kepala Keluarga", "${demografi.totalKk} KK", Color.Black)
                    LaporanRow("Total Penduduk Terdaftar", "${demografi.totalWarga} Jiwa", Color.Black)
                    LaporanRow("Jumlah Laki-laki", "${demografi.totalLakiLaki} Jiwa", Color(0xFF2563EB))
                    LaporanRow("Jumlah Perempuan", "${demografi.totalPerempuan} Jiwa", Color(0xFFEC4899))
                }
            }
        }

        // Section 4: Export Buttons (Bagikan WhatsApp / Ekspor CSV)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Ekspor & Bagikan Laporan",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Bagikan ringkasan laporan ke grup WhatsApp warga atau simpan format CSV.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, generateLaporanText())
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Bagikan Laporan RT"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bagikan Teks")
                        }

                        Button(
                            onClick = {
                                // CSV Export intent
                                val csvContent = StringBuilder().apply {
                                    append("Tanggal,Jenis,Kategori,Keterangan,Nominal,DicatatOleh\n")
                                    kasList.forEach { k ->
                                        append("\"${k.tanggal}\",\"${k.jenis}\",\"${k.kategori}\",\"${k.keterangan}\",${k.nominal},\"${k.dicatatOleh}\"\n")
                                    }
                                }.toString()

                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, csvContent)
                                    putExtra(Intent.EXTRA_SUBJECT, "Laporan_Kas_RT05_RW08.csv")
                                    type = "text/comma-separated-values"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Ekspor CSV Kas RT"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ekspor CSV")
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun LaporanRow(label: String, value: String, valueColor: Color, isBold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = valueColor
        )
    }
}
