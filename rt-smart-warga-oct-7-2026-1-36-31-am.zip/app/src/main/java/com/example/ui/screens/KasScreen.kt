package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.KasEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.KasOverviewBanner
import com.example.ui.components.StatusPill
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.RTViewModel
import com.example.util.FormatUtils

@Composable
fun KasScreen(
    viewModel: RTViewModel
) {
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val kasList by viewModel.allKas.collectAsStateWithLifecycle()
    val summary by viewModel.kasSummary.collectAsStateWithLifecycle()

    val canManage = currentRole.canManageKas()

    var selectedJenisFilter by remember { mutableStateOf("Semua") } // Semua, Pemasukan, Pengeluaran
    var selectedKategoriFilter by remember { mutableStateOf("Semua") }
    var selectedMonthFilter by remember { mutableStateOf("Semua") }

    var showAddDialog by remember { mutableStateOf(false) }
    var kasToDelete by remember { mutableStateOf<KasEntity?>(null) }
    var selectedKasDetail by remember { mutableStateOf<KasEntity?>(null) }

    val jenisOptions = listOf("Semua", "Pemasukan", "Pengeluaran")
    val monthOptions = listOf("Semua", "Oktober 2026", "September 2026")

    val kategoriPemasukan = listOf("Iuran Warga", "Sumbangan", "Bantuan", "Donasi", "Pendapatan Lainnya")
    val kategoriPengeluaran = listOf("Kegiatan RT", "Kebersihan", "Keamanan", "Perawatan Fasilitas", "Bantuan Sosial", "Konsumsi Rapat", "Administrasi", "Pengeluaran Lainnya")

    val filteredList = kasList.filter { item ->
        val matchesJenis = if (selectedJenisFilter == "Semua") true else item.jenis.equals(selectedJenisFilter, ignoreCase = true)
        val matchesKategori = if (selectedKategoriFilter == "Semua") true else item.kategori.equals(selectedKategoriFilter, ignoreCase = true)
        val matchesMonth = if (selectedMonthFilter == "Semua") true else item.tanggal.contains(selectedMonthFilter.take(3), ignoreCase = true)
        matchesJenis && matchesKategori && matchesMonth
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("kas_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Main Kas Overview Banner (Saldo = Pemasukan - Pengeluaran)
            item {
                KasOverviewBanner(
                    saldo = FormatUtils.formatRupiah(summary.saldo),
                    totalPemasukan = FormatUtils.formatRupiah(summary.totalPemasukan),
                    totalPengeluaran = FormatUtils.formatRupiah(summary.totalPengeluaran)
                )
            }

            // Visual Chart Component: Pemasukan vs Pengeluaran per Bulan
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Grafik Arus Kas Bulanan",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(GreenAccent)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Masuk", fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(ExpenseRed)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Keluar", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Custom Canvas Chart
                        KasMonthlyChart()
                    }
                }
            }

            // Filter Tabs
            item {
                Text(
                    text = "Filter Transaksi",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Filter Jenis
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(jenisOptions) { jenis ->
                            FilterChip(
                                selected = selectedJenisFilter == jenis,
                                onClick = {
                                    selectedJenisFilter = jenis
                                    selectedKategoriFilter = "Semua"
                                },
                                label = { Text(jenis) }
                            )
                        }
                    }

                    // Filter Bulan
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(monthOptions) { month ->
                            FilterChip(
                                selected = selectedMonthFilter == month,
                                onClick = { selectedMonthFilter = month },
                                label = { Text(month) }
                            )
                        }
                    }
                }
            }

            // Section Header with count
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Riwayat Transaksi (${filteredList.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (canManage) "Hak Kelola: Bendahara" else "Warga: Hanya Lihat",
                        fontSize = 11.sp,
                        color = if (canManage) GreenAccent else Color.Gray,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            items(filteredList) { item ->
                KasItemCard(
                    item = item,
                    canManage = canManage,
                    onClick = { selectedKasDetail = item },
                    onDelete = { kasToDelete = item }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // FAB Tambah Transaksi untuk Bendahara/Ketua RT
        if (canManage) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = NavyPrimary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_kas_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Transaksi")
            }
        }
    }

    // Detail Dialog
    if (selectedKasDetail != null) {
        val k = selectedKasDetail!!
        AlertDialog(
            onDismissRequest = { selectedKasDetail = null },
            title = {
                Text(
                    text = "Rincian Transaksi Kas",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(text = k.jenis, statusType = if (k.jenis == "Pemasukan") "LUNAS" else "BELUM LUNAS")
                        Text(text = k.tanggal, fontSize = 12.sp, color = Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = FormatUtils.formatRupiah(k.nominal),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (k.jenis == "Pemasukan") GreenAccent else ExpenseRed
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Kategori: ${k.kategori}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(text = "Keterangan: ${k.keterangan}", fontSize = 13.sp)
                    Text(text = "Bukti Transaksi: ${k.bukti}", fontSize = 12.sp, color = Color.Gray)
                    Text(text = "Dicatat Oleh: ${k.dicatatOleh}", fontSize = 12.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedKasDetail = null }) {
                    Text("Tutup")
                }
            }
        )
    }

    // Add Kas Dialog
    if (showAddDialog) {
        KasFormDialog(
            kategoriPemasukan = kategoriPemasukan,
            kategoriPengeluaran = kategoriPengeluaran,
            onDismiss = { showAddDialog = false },
            onSave = { jenis, kategori, keterangan, nominal, bukti ->
                viewModel.addKas(jenis, kategori, keterangan, nominal, bukti)
                showAddDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    if (kasToDelete != null) {
        val toDel = kasToDelete!!
        ConfirmDeleteDialog(
            title = "Hapus Transaksi Kas",
            message = "Apakah Anda yakin ingin menghapus transaksi '${toDel.keterangan}' sebesar ${FormatUtils.formatRupiah(toDel.nominal)}? Data saldo kas akan otomatis disesuaikan.",
            onConfirm = {
                viewModel.deleteKas(toDel)
                kasToDelete = null
            },
            onDismiss = { kasToDelete = null }
        )
    }
}

@Composable
fun KasMonthlyChart() {
    // 3 Months visual data: Agustus, September, Oktober
    val months = listOf("Ags", "Sep", "Okt")
    val pemasukanValues = listOf(6.0f, 6.8f, 6.7f) // in millions
    val pengeluaranValues = listOf(4.2f, 0.95f, 4.55f)

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        val width = size.width
        val height = size.height
        val maxVal = 8.0f // max scale 8 juta
        val barGroupWidth = width / months.size
        val barWidth = 24.dp.toPx()

        // Draw horizontal grid lines
        val lineCount = 3
        for (i in 0..lineCount) {
            val y = height - (i.toFloat() / lineCount) * (height - 30.dp.toPx())
            drawLine(
                color = Color.LightGray.copy(alpha = 0.35f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
        }

        months.forEachIndexed { index, _ ->
            val groupCenterX = (index * barGroupWidth) + (barGroupWidth / 2)

            // Pemasukan Bar (Green)
            val pemHeight = (pemasukanValues[index] / maxVal) * (height - 35.dp.toPx())
            val pemLeft = groupCenterX - barWidth - 4.dp.toPx()
            val pemTop = height - pemHeight - 20.dp.toPx()

            drawRoundRect(
                color = GreenAccent,
                topLeft = Offset(pemLeft, pemTop),
                size = Size(barWidth, pemHeight),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )

            // Pengeluaran Bar (Red)
            val pengHeight = (pengeluaranValues[index] / maxVal) * (height - 35.dp.toPx())
            val pengLeft = groupCenterX + 4.dp.toPx()
            val pengTop = height - pengHeight - 20.dp.toPx()

            drawRoundRect(
                color = ExpenseRed,
                topLeft = Offset(pengLeft, pengTop),
                size = Size(barWidth, pengHeight),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        Text("Agustus", fontSize = 11.sp, color = Color.Gray)
        Text("September", fontSize = 11.sp, color = Color.Gray)
        Text("Oktober (Bulan Ini)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
    }
}

@Composable
fun KasItemCard(
    item: KasEntity,
    canManage: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val isPemasukan = item.jenis.equals("Pemasukan", ignoreCase = true)
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (isPemasukan) GreenAccent.copy(alpha = 0.15f) else ExpenseRed.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPemasukan) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                    contentDescription = item.jenis,
                    tint = if (isPemasukan) GreenAccent else ExpenseRed,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.keterangan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${item.tanggal} • ${item.kategori}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Bukti: ${item.bukti}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isPemasukan) "+" else "-"} ${FormatUtils.formatRupiah(item.nominal)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPemasukan) GreenAccent else ExpenseRed
                )
                if (canManage) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Hapus",
                            tint = ExpenseRed.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KasFormDialog(
    kategoriPemasukan: List<String>,
    kategoriPengeluaran: List<String>,
    onDismiss: () -> Unit,
    onSave: (jenis: String, kategori: String, keterangan: String, nominal: Long, bukti: String) -> Unit
) {
    var jenis by remember { mutableStateOf("Pemasukan") }
    var kategori by remember { mutableStateOf(kategoriPemasukan.first()) }
    var keterangan by remember { mutableStateOf("") }
    var nominalText by remember { mutableStateOf("") }
    var bukti by remember { mutableStateOf("Nota Pembelian") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "Catat Transaksi Kas Baru", fontWeight = FontWeight.Bold)
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(text = "Jenis Transaksi:", fontSize = 12.sp, color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = jenis == "Pemasukan",
                            onClick = {
                                jenis = "Pemasukan"
                                kategori = kategoriPemasukan.first()
                            },
                            label = { Text("Pemasukan") }
                        )
                        FilterChip(
                            selected = jenis == "Pengeluaran",
                            onClick = {
                                jenis = "Pengeluaran"
                                kategori = kategoriPengeluaran.first()
                            },
                            label = { Text("Pengeluaran") }
                        )
                    }
                }

                item {
                    Text(text = "Kategori:", fontSize = 12.sp, color = Color.Gray)
                    val activeCategories = if (jenis == "Pemasukan") kategoriPemasukan else kategoriPengeluaran
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(activeCategories) { kat ->
                            FilterChip(
                                selected = kategori == kat,
                                onClick = { kategori = kat },
                                label = { Text(kat) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = nominalText,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() }) nominalText = input
                        },
                        label = { Text("Nominal (Rp)*") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = keterangan,
                        onValueChange = { keterangan = it },
                        label = { Text("Keterangan Transaksi*") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = bukti,
                        onValueChange = { bukti = it },
                        label = { Text("Bukti Transaksi (Kuitansi / Nota / Transfer)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val nominal = nominalText.toLongOrNull() ?: 0L
                    if (nominal > 0L && keterangan.isNotBlank()) {
                        onSave(jenis, kategori, keterangan, nominal, bukti)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
