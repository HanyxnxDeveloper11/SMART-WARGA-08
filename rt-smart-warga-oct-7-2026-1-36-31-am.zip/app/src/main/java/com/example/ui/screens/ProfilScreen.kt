package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.ui.components.RoleBadge
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel

@Composable
fun ProfilScreen(
    viewModel: RTViewModel
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()

    var showSwitchUserDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profil_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // User Profile Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser?.nama?.split(" ")?.filter { it.isNotBlank() }?.take(2)?.map { it.first().uppercase() }?.joinToString("") ?: "W",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = currentUser?.nama ?: "Pengguna",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = currentUser?.email ?: "",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    RoleBadge(role = currentRole)

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showSwitchUserDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("switch_user_button")
                    ) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Beralih Akun / Role", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Penjelasan Hak Akses Akun Aktif
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Hak Akses & Otorisasi (${currentRole.label})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    when (currentRole) {
                        UserRole.ADMIN_KETUA_RT -> {
                            HakAksesItem("Mengelola data seluruh warga & mutasi kependudukan", true)
                            HakAksesItem("Melihat NIK, No. KK & Nomor HP lengkap", true)
                            HakAksesItem("Mengelola kas RT & otorisasi pengeluaran", true)
                            HakAksesItem("Otorisasi dan persetujuan surat warga", true)
                            HakAksesItem("Menerbitkan pengumuman & jadwal kegiatan", true)
                            HakAksesItem("Melihat laporan komprehensif RT", true)
                        }
                        UserRole.BENDAHARA -> {
                            HakAksesItem("Mencatat transaksi kas (Pemasukan & Pengeluaran)", true)
                            HakAksesItem("Mencatat dan memverifikasi setoran iuran warga", true)
                            HakAksesItem("Mengakses laporan keuangan & ekspor CSV", true)
                            HakAksesItem("Data sensitif NIK warga dilindungi (akses terbatas)", false)
                        }
                        UserRole.SEKRETARIS -> {
                            HakAksesItem("Mengelola data warga & NIK kependudukan", true)
                            HakAksesItem("Membuat dan mengelola surat administrasi warga", true)
                            HakAksesItem("Menerbitkan pengumuman & kegiatan RT", true)
                            HakAksesItem("Mengubah transaksi kas (Hanya Ketua RT & Bendahara)", false)
                        }
                        UserRole.WARGA -> {
                            HakAksesItem("Melihat transparansi kas RT secara jelas (Read-Only)", true)
                            HakAksesItem("Melihat riwayat setoran iuran milik sendiri", true)
                            HakAksesItem("Melihat pengumuman & jadwal kegiatan mendatang", true)
                            HakAksesItem("Mengajukan permohonan surat administrasi", true)
                            HakAksesItem("Melihat data NIK/KK/No HP warga lain (Dibatasi/Sensor)", false)
                            HakAksesItem("Mengubah data kas atau iuran (Dilarang)", false)
                        }
                    }
                }
            }
        }

        // Kontak Darurat & Pengurus RT
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Kontak Pengurus & Layanan Darurat",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    KontakRow("Ketua RT 05 (Bpk. Bambang)", "0812-8833-9001", Icons.Default.Person)
                    KontakRow("Pos Jaga & Ronda Malam", "0815-9988-7711", Icons.Default.Security)
                    KontakRow("Bhabinkamtibmas / Polsek", "021-8761234", Icons.Default.Security)
                    KontakRow("Puskesmas Sukamaju", "021-8774321", Icons.Default.LocalHospital)
                }
            }
        }

        // Informasi Aplikasi
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Tentang Aplikasi", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "RT Smart Warga v1.0 • Aplikasi sistem administrasi rukun tetangga berbasis digital yang mengutamakan transparansi kas, perlindungan privasi data warga, dan kemudahan pelayanan surat menyurat.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        lineHeight = 17.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Quick Switch User Dialog
    if (showSwitchUserDialog) {
        AlertDialog(
            onDismissRequest = { showSwitchUserDialog = false },
            title = {
                Text(text = "Beralih Akun Pengguna", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Pilih akun berikut untuk menguji hak akses role yang berbeda langsung di aplikasi:",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    allUsers.forEach { user ->
                        val uRole = try { UserRole.valueOf(user.role) } catch (e: Exception) { UserRole.WARGA }
                        val isSelected = user.id == currentUser?.id

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) NavyPrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) NavyPrimary else Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.switchUser(user)
                                    showSwitchUserDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = user.nama,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = uRole.label,
                                        fontSize = 11.sp,
                                        color = NavyPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = user.email,
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = GreenAccent)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSwitchUserDialog = false }) {
                    Text("Tutup")
                }
            }
        )
    }
}

@Composable
fun HakAksesItem(text: String, granted: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (granted) Icons.Default.Check else Icons.Default.Lock,
            contentDescription = null,
            tint = if (granted) GreenAccent else ExpenseRed,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            color = if (granted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
    }
}

@Composable
fun KontakRow(label: String, phone: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = NavyLight, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(text = phone, fontSize = 12.sp, color = GreenAccent, fontWeight = FontWeight.Bold)
        }
    }
}
