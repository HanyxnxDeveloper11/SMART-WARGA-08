package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF1A365D)
val NavyLight = Color(0xFF2A4365)
val NavyDark = Color(0xFF0F1E36)

val GreenAccent = Color(0xFF10B981)
val GreenLight = Color(0xFFD1FAE5)
val GreenDark = Color(0xFF065F46)

val ExpenseRed = Color(0xFFEF4444)
val ExpenseRedLight = Color(0xFFFEE2E2)
val WarningAmber = Color(0xFFF59E0B)
val InfoBlue = Color(0xFF0284C7)

val SurfaceLight = Color(0xFFF8FAFC)
val BackgroundLight = Color(0xFFF1F5F9)
val CardBorderLight = Color(0xFFE2E8F0)

val SurfaceDark = Color(0xFF0F172A)
val BackgroundDark = Color(0xFF0B1120)
val CardBorderDark = Color(0xFF1E293B)
