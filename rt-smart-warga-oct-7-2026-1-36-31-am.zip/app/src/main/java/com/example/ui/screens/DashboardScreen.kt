package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.PengumumanEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.ui.components.KasOverviewBanner
import com.example.ui.components.RoleBadge
import com.example.ui.components.StatCard
import com.example.ui.components.StatusPill
import com.example.ui.navigation.NavScreen
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.RTViewModel
import com.example.util.FormatUtils

@Composable
fun DashboardScreen(
    viewModel: RTViewModel,
    onNavigate: (NavScreen) -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val kasSummary by viewModel.kasSummary.collectAsStateWithLifecycle()
    val demografi by viewModel.demografiSummary.collectAsStateWithLifecycle()
    val kegiatanList by viewModel.allKegiatan.collectAsStateWithLifecycle()
    val pengumumanList by viewModel.allPengumuman.collectAsStateWithLifecycle()

    val upcomingCount = kegiatanList.count { it.status.equals("Akan Datang", ignoreCase = true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header & Identity Banner
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = NavyPrimary,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "RT 05 / RW 08",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Kel. Sukamaju, Kec. Cilodong",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "RT Smart Warga",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary
                            )
                        }

                        RoleBadge(role = currentRole)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Selamat datang, ${currentUser?.nama ?: "Warga"}. Portal administrasi lingkungan transparan, guyub, dan modern.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Hero Graphic Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.hero_banner),
                            contentDescription = "Lingkungan RT Smart Warga",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, NavyDark.copy(alpha = 0.8f))
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = GreenAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Lingkungan Guyub, Aman & Bebas Pungli",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Prominent Kas RT Banner
        item {
            KasOverviewBanner(
                saldo = FormatUtils.formatRupiah(kasSummary.saldo),
                totalPemasukan = FormatUtils.formatRupiah(kasSummary.totalPemasukan),
                totalPengeluaran = FormatUtils.formatRupiah(kasSummary.totalPengeluaran),
                modifier = Modifier.testTag("dashboard_kas_banner"),
                onDetailClick = { onNavigate(NavScreen.KAS) }
            )
        }

        // Quick Stats Row (KK, Penduduk, Kegiatan)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Kepala Keluarga",
                    value = "${demografi.totalKk} KK",
                    icon = Icons.Default.People,
                    iconColor = NavyPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(NavScreen.WARGA) }
                )
                StatCard(
                    title = "Total Penduduk",
                    value = "${demografi.totalWarga} Jiwa",
                    icon = Icons.Default.People,
                    iconColor = GreenAccent,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(NavScreen.WARGA) }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Kegiatan Datang",
                    value = "$upcomingCount Agenda",
                    icon = Icons.Default.Event,
                    iconColor = WarningAmber,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(NavScreen.KEGIATAN) }
                )
                StatCard(
                    title = "Pengumuman Aktif",
                    value = "${pengumumanList.size} Info",
                    icon = Icons.Default.Campaign,
                    iconColor = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(NavScreen.PENGUMUMAN) }
                )
            }
        }

        // Main 9 Menu Grid Section
        item {
            Text(
                text = "Menu Layanan Warga",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row 1: Beranda, Data Warga, Transparansi Kas
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MenuGridItem(
                        title = "Beranda",
                        icon = Icons.Default.Home,
                        color = NavyPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.BERANDA) }
                    )
                    MenuGridItem(
                        title = "Data Warga",
                        icon = Icons.Default.People,
                        color = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.WARGA) }
                    )
                    MenuGridItem(
                        title = "Kas RT",
                        icon = Icons.Default.AccountBalanceWallet,
                        color = GreenAccent,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.KAS) }
                    )
                }

                // Row 2: Iuran Warga, Kegiatan RT, Pengumuman
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MenuGridItem(
                        title = "Iuran Warga",
                        icon = Icons.Default.Payment,
                        color = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.IURAN) }
                    )
                    MenuGridItem(
                        title = "Kegiatan RT",
                        icon = Icons.Default.Event,
                        color = WarningAmber,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.KEGIATAN) }
                    )
                    MenuGridItem(
                        title = "Pengumuman",
                        icon = Icons.Default.Campaign,
                        color = Color(0xFFEA580C),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.PENGUMUMAN) }
                    )
                }

                // Row 3: Surat, Laporan, Profil
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MenuGridItem(
                        title = "Surat Warga",
                        icon = Icons.Default.Assignment,
                        color = Color(0xFF0D9488),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.SURAT) }
                    )
                    MenuGridItem(
                        title = "Laporan",
                        icon = Icons.Default.BarChart,
                        color = Color(0xFF4F46E5),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.LAPORAN) }
                    )
                    MenuGridItem(
                        title = "Profil",
                        icon = Icons.Default.Person,
                        color = Color(0xFF64748B),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(NavScreen.PROFIL) }
                    )
                }
            }
        }

        // Pengumuman Terbaru Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Pengumuman Terbaru",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = { onNavigate(NavScreen.PENGUMUMAN) }) {
                    Text("Semua", fontSize = 13.sp, color = NavyPrimary)
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = NavyPrimary
                    )
                }
            }
        }

        items(pengumumanList.take(2)) { p ->
            PengumumanMiniCard(
                pengumuman = p,
                onClick = { onNavigate(NavScreen.PENGUMUMAN) }
            )
        }

        // Kegiatan Terdekat Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Kegiatan Mendatang",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = { onNavigate(NavScreen.KEGIATAN) }) {
                    Text("Semua", fontSize = 13.sp, color = NavyPrimary)
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = NavyPrimary
                    )
                }
            }
        }

        items(kegiatanList.filter { it.status == "Akan Datang" }.take(2)) { k ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(NavScreen.KEGIATAN) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(NavyPrimary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = NavyPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = k.namaKegiatan,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${k.tanggal} • ${k.waktu}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                    StatusPill(text = "${k.rsvpCount} Warga", statusType = "TETAP")
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun MenuGridItem(
    title: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 14.dp, horizontal = 8.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun PengumumanMiniCard(
    pengumuman: PengumumanEntity,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(text = pengumuman.status, statusType = pengumuman.status)
                Text(
                    text = pengumuman.tanggal,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = pengumuman.judul,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = pengumuman.isi,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 16.sp
            )
        }
    }
}
