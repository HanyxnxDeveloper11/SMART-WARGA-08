package com.example.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FormatUtils {
    private val indonesianLocale = Locale("in", "ID")

    fun formatRupiah(amount: Long): String {
        val formatter = NumberFormat.getCurrencyInstance(indonesianLocale)
        formatter.maximumFractionDigits = 0
        return formatter.format(amount).replace("Rp", "Rp ")
    }

    fun getCurrentDateFormatted(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", indonesianLocale)
        return sdf.format(Date())
    }

    fun getCurrentMonthYear(): String {
        val sdf = SimpleDateFormat("MMMM yyyy", indonesianLocale)
        return sdf.format(Date())
    }

    fun maskNik(nik: String): String {
        if (nik.length < 8) return "******"
        return nik.take(4) + "********" + nik.takeLast(4)
    }

    fun maskNoKk(noKk: String): String {
        if (noKk.length < 8) return "******"
        return noKk.take(4) + "********" + noKk.takeLast(4)
    }

    fun maskPhone(phone: String): String {
        if (phone.length < 8) return "******"
        return phone.take(4) + "****" + phone.takeLast(4)
    }

    fun generateNomorSurat(suratCount: Int): String {
        val sdfMonth = SimpleDateFormat("M", indonesianLocale)
        val monthRoman = when (sdfMonth.format(Date())) {
            "1" -> "I"
            "2" -> "II"
            "3" -> "III"
            "4" -> "IV"
            "5" -> "V"
            "6" -> "VI"
            "7" -> "VII"
            "8" -> "VIII"
            "9" -> "IX"
            "10" -> "X"
            "11" -> "XI"
            "12" -> "XII"
            else -> "X"
        }
        val year = SimpleDateFormat("yyyy", indonesianLocale).format(Date())
        val seq = (suratCount + 44).toString().padStart(3, '0')
        return "$seq/RT.05/RW.08/$monthRoman/$year"
    }
}
