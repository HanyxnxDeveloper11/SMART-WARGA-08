package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.IuranEntity
import com.example.data.model.KasEntity
import com.example.data.model.KegiatanEntity
import com.example.data.model.PengumumanEntity
import com.example.data.model.SuratEntity
import com.example.data.model.UserEntity
import com.example.data.model.WargaEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        WargaEntity::class,
        KasEntity::class,
        IuranEntity::class,
        KegiatanEntity::class,
        PengumumanEntity::class,
        SuratEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun wargaDao(): WargaDao
    abstract fun kasDao(): KasDao
    abstract fun iuranDao(): IuranDao
    abstract fun kegiatanDao(): KegiatanDao
    abstract fun pengumumanDao(): PengumumanDao
    abstract fun suratDao(): SuratDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rt_smart_warga.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        INSTANCE?.let { database ->
                            CoroutineScope(Dispatchers.IO).launch {
                                populateInitialData(database)
                            }
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            // Seed Users
            val users = listOf(
                UserEntity("U-01", "Bpk. H. Bambang Sutrisno", "ketua.rt05@sukamaju.id", "ADMIN_KETUA_RT", "W-001", "A-01"),
                UserEntity("U-02", "Ibu Hj. Sri Wahyuni, SE", "bendahara@sukamaju.id", "BENDAHARA", "W-002", "A-04"),
                UserEntity("U-03", "Bpk. Agus Prasetyo, S.Kom", "sekretaris@sukamaju.id", "SEKRETARIS", "W-003", "B-02"),
                UserEntity("U-04", "Bpk. Budi Santoso", "budi.santoso@gmail.com", "WARGA", "W-004", "B-12"),
                UserEntity("U-05", "Ibu Siti Rahmawati", "siti.rahmawati@gmail.com", "WARGA", "W-005", "C-05")
            )
            db.userDao().insertAll(users)

            // Seed Warga
            val wargaList = listOf(
                WargaEntity("W-001", "Bpk. H. Bambang Sutrisno", "3276011405680001", "3276011002010001", "Laki-laki", "Jakarta", "14 Mei 1968", "Kawin", "Pensiunan BUMN", "Blok A No. 01", "081288339001", "Tetap"),
                WargaEntity("W-002", "Ibu Hj. Sri Wahyuni, SE", "3276015509740002", "3276011002010002", "Perempuan", "Bandung", "15 September 1974", "Kawin", "Akuntan Publik", "Blok A No. 04", "081399442002", "Tetap"),
                WargaEntity("W-003", "Bpk. Agus Prasetyo, S.Kom", "3276012008850003", "3276011002010003", "Laki-laki", "Depok", "20 Agustus 1985", "Kawin", "Software Engineer", "Blok B No. 02", "081577221199", "Tetap"),
                WargaEntity("W-004", "Bpk. Budi Santoso", "3276011003900004", "3276011002010004", "Laki-laki", "Solo", "10 Maret 1990", "Kawin", "Karyawan Swasta", "Blok B No. 12", "085712345678", "Tetap"),
                WargaEntity("W-005", "Ibu Siti Rahmawati", "3276014512920005", "3276011002010005", "Perempuan", "Yogyakarta", "05 Desember 1992", "Kawin", "Guru SD", "Blok C No. 05", "087890123456", "Tetap"),
                WargaEntity("W-006", "Hendra Gunawan", "3276011806980006", "3276011002010006", "Laki-laki", "Medan", "18 Juni 1998", "Belum Kawin", "Desainer Grafis", "Blok C No. 08", "089611223344", "Kontrak"),
                WargaEntity("W-007", "Dedi Supriadi", "3276012501010007", "3276011002010007", "Laki-laki", "Ciamis", "25 Januari 2001", "Belum Kawin", "Mahasiswa", "Blok D No. 02", "085233445566", "Kost"),
                WargaEntity("W-008", "Nurul Aini", "3276016204890008", "3276011002010008", "Perempuan", "Semarang", "22 April 1989", "Kawin", "Wirausaha Kuliner", "Blok D No. 09", "081122334455", "Tetap"),
                WargaEntity("W-009", "Rahmat Hidayat", "3276010507720009", "3276011002010009", "Laki-laki", "Bogor", "05 Juli 1972", "Kawin", "Pedagang Toko", "Blok E No. 03", "081822334411", "Tetap"),
                WargaEntity("W-010", "Maria Ulfa", "3276014909830010", "3276011002010010", "Perempuan", "Surabaya", "09 September 1983", "Kawin", "Pegawai Negeri Sipil", "Blok E No. 07", "081733445522", "Tetap")
            )
            db.wargaDao().insertAll(wargaList)

            // Seed Kas
            val kasList = listOf(
                KasEntity(0, "01 Okt 2026", "Pemasukan", "Iuran Warga", "Penerimaan Iuran Warga Periode Oktober (Gelombang 1)", 5200000L, "Bukti Setoran Kolektif", "Bendahara RT"),
                KasEntity(0, "02 Okt 2026", "Pengeluaran", "Kebersihan", "Honor Pengangkut Sampah Lingkungan Bulan Oktober", 1500000L, "Kuitansi Petugas Kebersihan", "Bendahara RT"),
                KasEntity(0, "03 Okt 2026", "Pengeluaran", "Keamanan", "Honor Jaga Malam 2 Petugas Satpam Pos Ronda", 2400000L, "Kuitansi Pos Keamanan", "Bendahara RT"),
                KasEntity(0, "04 Okt 2026", "Pemasukan", "Sumbangan", "Sumbangan Sukarela Warga Baru Masuk B-12", 500000L, "Bukti Transfer BCA", "Bendahara RT"),
                KasEntity(0, "05 Okt 2026", "Pengeluaran", "Perawatan Fasilitas", "Pembelian Lampu LED Jalan Gang Blok B & Cat Gapura", 650000L, "Nota Toko Bangunan Terang", "Bendahara RT"),
                KasEntity(0, "05 Okt 2026", "Pemasukan", "Donasi", "Donasi Pengembangan Balai Warga dari Donatur Peduli", 1000000L, "Bukti Transfer Mandiri", "Ketua RT"),
                KasEntity(0, "25 Sep 2026", "Pemasukan", "Iuran Warga", "Penerimaan Iuran Warga Periode September Penuh", 6800000L, "Rekap Kas Bulanan", "Bendahara RT"),
                KasEntity(0, "28 Sep 2026", "Pengeluaran", "Konsumsi Rapat", "Konsumsi & Snack Musyawarah Warga Triwulan III", 450000L, "Nota Snack Berkah", "Sekretaris RT"),
                KasEntity(0, "15 Sep 2026", "Pengeluaran", "Bantuan Sosial", "Santunan Duka Cita Warga Blok D", 500000L, "Kuitansi Kas Sosial", "Ketua RT"),
                KasEntity(0, "01 Sep 2026", "Pemasukan", "Pendapatan Lainnya", "Penyewaan Tenda & Kursi Inventaris RT untuk Hajatan", 600000L, "Tanda Terima Inventaris", "Pengurus RT")
            )
            db.kasDao().insertAll(kasList)

            // Seed Iuran
            val iuranList = listOf(
                IuranEntity(0, "W-001", "Bpk. H. Bambang Sutrisno", "Blok A No. 01", "Oktober 2026", "Iuran Bulanan", 100000L, "01 Okt 2026", "Lunas"),
                IuranEntity(0, "W-002", "Ibu Hj. Sri Wahyuni, SE", "Blok A No. 04", "Oktober 2026", "Iuran Bulanan", 100000L, "01 Okt 2026", "Lunas"),
                IuranEntity(0, "W-003", "Bpk. Agus Prasetyo, S.Kom", "Blok B No. 02", "Oktober 2026", "Iuran Bulanan", 100000L, "02 Okt 2026", "Lunas"),
                IuranEntity(0, "W-004", "Bpk. Budi Santoso", "Blok B No. 12", "Oktober 2026", "Iuran Bulanan", 100000L, "03 Okt 2026", "Lunas"),
                IuranEntity(0, "W-005", "Ibu Siti Rahmawati", "Blok C No. 05", "Oktober 2026", "Iuran Bulanan", 100000L, null, "Belum Lunas"),
                IuranEntity(0, "W-006", "Hendra Gunawan", "Blok C No. 08", "Oktober 2026", "Iuran Bulanan", 100000L, null, "Belum Lunas"),
                IuranEntity(0, "W-007", "Dedi Supriadi", "Blok D No. 02", "Oktober 2026", "Kebersihan & Keamanan", 50000L, null, "Belum Lunas"),
                IuranEntity(0, "W-008", "Nurul Aini", "Blok D No. 09", "Oktober 2026", "Iuran Bulanan", 100000L, "04 Okt 2026", "Lunas"),
                IuranEntity(0, "W-009", "Rahmat Hidayat", "Blok E No. 03", "Oktober 2026", "Iuran Bulanan", 100000L, "03 Okt 2026", "Lunas"),
                IuranEntity(0, "W-010", "Maria Ulfa", "Blok E No. 07", "Oktober 2026", "Iuran Bulanan", 100000L, null, "Belum Lunas")
            )
            db.iuranDao().insertAll(iuranList)

            // Seed Kegiatan
            val kegiatanList = listOf(
                KegiatanEntity(
                    id = 0,
                    namaKegiatan = "Kerja Bakti Akbar & Bersih Saluran Air",
                    tanggal = "12 Okt 2026",
                    waktu = "07:00 - 10:30 WIB",
                    lokasi = "Seluruh Lingkungan RT 05",
                    penanggungJawab = "Seksi Kebersihan (Bpk. Agus)",
                    anggaran = 350000L,
                    deskripsi = "Menghadapi musim hujan, seluruh warga bergotong-royong membersihkan drainase utama dan merapikan tanaman.",
                    status = "Akan Datang",
                    rsvpCount = 28
                ),
                KegiatanEntity(
                    id = 0,
                    namaKegiatan = "Posyandu Balita & Lansia Flamboyan",
                    tanggal = "18 Okt 2026",
                    waktu = "08:30 - 11:30 WIB",
                    lokasi = "Balai Warga RT 05",
                    penanggungJawab = "Ibu-Ibu Kader PKK",
                    anggaran = 500000L,
                    deskripsi = "Pemeriksaan tumbuh kembang balita, imunisasi berkala, serta skrining gula darah dan tensi gratis bagi lansia.",
                    status = "Akan Datang",
                    rsvpCount = 34
                ),
                KegiatanEntity(
                    id = 0,
                    namaKegiatan = "Rapat Musyawarah Warga Pembahasan CCTV",
                    tanggal = "25 Okt 2026",
                    waktu = "19:30 - 21:30 WIB",
                    lokasi = "Balai Pertemuan Warga RT 05",
                    penanggungJawab = "Ketua RT 05 (Bpk. Bambang)",
                    anggaran = 250000L,
                    deskripsi = "Musyawarah bersama warga mengenai rencana penambahan 4 unit CCTV keamanan lingkungan di gerbang dan pertigaan.",
                    status = "Akan Datang",
                    rsvpCount = 21
                ),
                KegiatanEntity(
                    id = 0,
                    namaKegiatan = "Peringatan HUT RI ke-81 & Pesta Rakyat",
                    tanggal = "17 Agu 2026",
                    waktu = "08:00 - 22:00 WIB",
                    lokasi = "Lapangan Utama RT 05",
                    penanggungJawab = "Karang Taruna RT 05",
                    anggaran = 4200000L,
                    deskripsi = "Rangkaian lomba jalan sehat, tarik tambang, lomba anak-anak, dan malam ramah tamah warga.",
                    status = "Selesai",
                    rsvpCount = 92
                )
            )
            db.kegiatanDao().insertAll(kegiatanList)

            // Seed Pengumuman
            val pengumumanList = listOf(
                PengumumanEntity(
                    id = 0,
                    judul = "Kerja Bakti Serentak Menyambut Musim Penghujan",
                    isi = "Diberitahukan kepada seluruh warga RT 05 / RW 08 bahwa kerja bakti serentak pembersihan saluran air akan diadakan pada hari Minggu, 12 Oktober 2026 pukul 07.00 WIB. Diharapkan partisipasi tiap kepala keluarga.",
                    tanggal = "05 Okt 2026",
                    lampiran = "Jadwal_Kerjabakti.pdf",
                    status = "Penting",
                    penanggungJawab = "Ketua RT 05"
                ),
                PengumumanEntity(
                    id = 0,
                    judul = "Sosialisasi Pemilahan Sampah Rumah Tangga",
                    isi = "Mulai pertengahan Oktober 2026, petugas sampah akan memilah sampah kering dan basah. Tempat sampah terpilah dapat diambil gratis di Balai RT.",
                    tanggal = "03 Okt 2026",
                    lampiran = "",
                    status = "Biasa",
                    penanggungJawab = "Seksi Lingkungan Hidup"
                ),
                PengumumanEntity(
                    id = 0,
                    judul = "Himbauan Keamanan Portal Gang Malam Hari",
                    isi = "Portal utama RT 05 akan ditutup setiap malam pukul 23.00 - 05.00 WIB demi keamanan lingkungan. Tamu bermalam wajib melapor ke pos satpam.",
                    tanggal = "29 Sep 2026",
                    lampiran = "",
                    status = "Mendesak",
                    penanggungJawab = "Seksi Keamanan RT"
                )
            )
            db.pengumumanDao().insertAll(pengumumanList)

            // Seed Surat
            val suratList = listOf(
                SuratEntity(
                    id = 0,
                    jenisSurat = "Surat Pengantar RT/RW",
                    wargaId = "W-004",
                    namaWarga = "Bpk. Budi Santoso",
                    nikWarga = "3276011003900004",
                    nomorRumah = "Blok B No. 12",
                    nomorSurat = "041/RT.05/RW.08/X/2026",
                    tanggal = "04 Okt 2026",
                    keperluan = "Pengantar Penerbitan SKCK di Polsek Cilodong",
                    keterangan = "Pemohon berkelakuan baik dan tidak pernah tersangkut tindak pidana.",
                    status = "Disetujui"
                ),
                SuratEntity(
                    id = 0,
                    jenisSurat = "Surat Keterangan Domisili",
                    wargaId = "W-006",
                    namaWarga = "Hendra Gunawan",
                    nikWarga = "3276011806980006",
                    nomorRumah = "Blok C No. 08",
                    nomorSurat = "042/RT.05/RW.08/X/2026",
                    tanggal = "05 Okt 2026",
                    keperluan = "Persyaratan Administrasi Pembukaan Rekening Bank",
                    keterangan = "Benar bertempat tinggal dan mengontrak di alamat RT 05 sejak Januari 2025.",
                    status = "Disetujui"
                ),
                SuratEntity(
                    id = 0,
                    jenisSurat = "Surat Keterangan Usaha (SKU)",
                    wargaId = "W-008",
                    namaWarga = "Nurul Aini",
                    nikWarga = "3276016204890008",
                    nomorRumah = "Blok D No. 09",
                    nomorSurat = "043/RT.05/RW.08/X/2026",
                    tanggal = "06 Okt 2026",
                    keperluan = "Pengajuan Tambahan Modal Usaha Mikro (Katering Rumahan)",
                    keterangan = "Memiliki usaha katering aktif di lingkungan RT 05.",
                    status = "Menunggu"
                )
            )
            db.suratDao().insertAll(suratList)
        }
    }
}
