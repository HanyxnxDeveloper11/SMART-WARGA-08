package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole(val label: String, val badgeColorHex: Long) {
    ADMIN_KETUA_RT("Ketua RT / Admin", 0xFF1A365D),
    BENDAHARA("Bendahara RT", 0xFF059669),
    SEKRETARIS("Sekretaris RT", 0xFF2563EB),
    WARGA("Warga", 0xFF64748B);

    fun canManageWarga(): Boolean = this == ADMIN_KETUA_RT || this == SEKRETARIS
    fun canManageKas(): Boolean = this == ADMIN_KETUA_RT || this == BENDAHARA
    fun canManageIuran(): Boolean = this == ADMIN_KETUA_RT || this == BENDAHARA
    fun canManageKegiatan(): Boolean = this == ADMIN_KETUA_RT || this == SEKRETARIS
    fun canManagePengumuman(): Boolean = this == ADMIN_KETUA_RT || this == SEKRETARIS
    fun canManageSurat(): Boolean = this == ADMIN_KETUA_RT || this == SEKRETARIS
    fun canViewReports(): Boolean = this != WARGA
    fun canSeeFullResidentDetails(): Boolean = this == ADMIN_KETUA_RT || this == SEKRETARIS
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val nama: String,
    val email: String,
    val role: String, // from UserRole.name
    val wargaId: String? = null,
    val nomorRumah: String? = null
)

@Entity(tableName = "warga")
data class WargaEntity(
    @PrimaryKey val id: String,
    val nama: String,
    val nik: String,
    val noKk: String,
    val jenisKelamin: String, // "Laki-laki" atau "Perempuan"
    val tempatLahir: String,
    val tanggalLahir: String,
    val statusPerkawinan: String,
    val pekerjaan: String,
    val nomorRumah: String,
    val noHp: String,
    val status: String // "Tetap", "Kontrak", "Kost", "Pindah", "Tidak Aktif"
)

@Entity(tableName = "kas")
data class KasEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tanggal: String,
    val jenis: String, // "Pemasukan" atau "Pengeluaran"
    val kategori: String,
    val keterangan: String,
    val nominal: Long,
    val bukti: String = "Nota Tercatat",
    val dicatatOleh: String = "Bendahara RT",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "iuran")
data class IuranEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wargaId: String,
    val namaWarga: String,
    val nomorRumah: String,
    val bulan: String, // e.g. "Oktober 2026"
    val jenisIuran: String, // "Iuran Bulanan", "Kebersihan", "Keamanan", dll
    val nominal: Long,
    val tanggalBayar: String? = null,
    val status: String // "Lunas" atau "Belum Lunas"
)

@Entity(tableName = "kegiatan")
data class KegiatanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val namaKegiatan: String,
    val tanggal: String,
    val waktu: String,
    val lokasi: String,
    val penanggungJawab: String,
    val anggaran: Long,
    val deskripsi: String,
    val status: String, // "Akan Datang", "Sedang Berlangsung", "Selesai"
    val rsvpCount: Int = 0
)

@Entity(tableName = "pengumuman")
data class PengumumanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val judul: String,
    val isi: String,
    val tanggal: String,
    val lampiran: String = "",
    val status: String, // "Penting", "Biasa", "Mendesak"
    val penanggungJawab: String = "Pengurus RT 05"
)

@Entity(tableName = "surat")
data class SuratEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jenisSurat: String,
    val wargaId: String,
    val namaWarga: String,
    val nikWarga: String,
    val nomorRumah: String,
    val nomorSurat: String,
    val tanggal: String,
    val keperluan: String,
    val keterangan: String = "",
    val status: String // "Menunggu", "Disetujui", "Ditolak"
)
