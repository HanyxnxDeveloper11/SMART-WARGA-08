package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.IuranEntity
import com.example.data.model.KasEntity
import com.example.data.model.KegiatanEntity
import com.example.data.model.PengumumanEntity
import com.example.data.model.SuratEntity
import com.example.data.model.UserEntity
import com.example.data.model.WargaEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WargaDao {
    @Query("SELECT * FROM warga ORDER BY nama ASC")
    fun getAllWarga(): Flow<List<WargaEntity>>

    @Query("SELECT * FROM warga WHERE id = :id LIMIT 1")
    suspend fun getWargaById(id: String): WargaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWarga(warga: WargaEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<WargaEntity>)

    @Update
    suspend fun updateWarga(warga: WargaEntity)

    @Query("DELETE FROM warga WHERE id = :id")
    suspend fun deleteWarga(id: String)

    @Query("SELECT COUNT(*) FROM warga")
    suspend fun getCount(): Int
}

@Dao
interface KasDao {
    @Query("SELECT * FROM kas ORDER BY timestamp DESC")
    fun getAllKas(): Flow<List<KasEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKas(kas: KasEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<KasEntity>)

    @Query("DELETE FROM kas WHERE id = :id")
    suspend fun deleteKas(id: Long)

    @Query("SELECT COUNT(*) FROM kas")
    suspend fun getCount(): Int
}

@Dao
interface IuranDao {
    @Query("SELECT * FROM iuran ORDER BY id DESC")
    fun getAllIuran(): Flow<List<IuranEntity>>

    @Query("SELECT * FROM iuran WHERE wargaId = :wargaId ORDER BY id DESC")
    fun getIuranByWarga(wargaId: String): Flow<List<IuranEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIuran(iuran: IuranEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<IuranEntity>)

    @Update
    suspend fun updateIuran(iuran: IuranEntity)

    @Query("UPDATE iuran SET status = :status, tanggalBayar = :tanggalBayar WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, tanggalBayar: String?)

    @Query("DELETE FROM iuran WHERE id = :id")
    suspend fun deleteIuran(id: Long)

    @Query("SELECT COUNT(*) FROM iuran")
    suspend fun getCount(): Int
}

@Dao
interface KegiatanDao {
    @Query("SELECT * FROM kegiatan ORDER BY id DESC")
    fun getAllKegiatan(): Flow<List<KegiatanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKegiatan(kegiatan: KegiatanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<KegiatanEntity>)

    @Update
    suspend fun updateKegiatan(kegiatan: KegiatanEntity)

    @Query("UPDATE kegiatan SET rsvpCount = rsvpCount + 1 WHERE id = :id")
    suspend fun incrementRsvp(id: Long)

    @Query("DELETE FROM kegiatan WHERE id = :id")
    suspend fun deleteKegiatan(id: Long)

    @Query("SELECT COUNT(*) FROM kegiatan")
    suspend fun getCount(): Int
}

@Dao
interface PengumumanDao {
    @Query("SELECT * FROM pengumuman ORDER BY id DESC")
    fun getAllPengumuman(): Flow<List<PengumumanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPengumuman(pengumuman: PengumumanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<PengumumanEntity>)

    @Query("DELETE FROM pengumuman WHERE id = :id")
    suspend fun deletePengumuman(id: Long)

    @Query("SELECT COUNT(*) FROM pengumuman")
    suspend fun getCount(): Int
}

@Dao
interface SuratDao {
    @Query("SELECT * FROM surat ORDER BY id DESC")
    fun getAllSurat(): Flow<List<SuratEntity>>

    @Query("SELECT * FROM surat WHERE wargaId = :wargaId ORDER BY id DESC")
    fun getSuratByWarga(wargaId: String): Flow<List<SuratEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSurat(surat: SuratEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<SuratEntity>)

    @Query("UPDATE surat SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Query("DELETE FROM surat WHERE id = :id")
    suspend fun deleteSurat(id: Long)

    @Query("SELECT COUNT(*) FROM surat")
    suspend fun getCount(): Int
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY id ASC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<UserEntity>)

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getCount(): Int
}
