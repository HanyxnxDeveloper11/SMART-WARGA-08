package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.IuranEntity
import com.example.data.model.KasEntity
import com.example.data.model.KegiatanEntity
import com.example.data.model.PengumumanEntity
import com.example.data.model.SuratEntity
import com.example.data.model.UserEntity
import com.example.data.model.WargaEntity
import kotlinx.coroutines.flow.Flow

class RTRepository(private val database: AppDatabase) {

    // Users
    val allUsers: Flow<List<UserEntity>> = database.userDao().getAllUsers()
    suspend fun insertUser(user: UserEntity) = database.userDao().insertUser(user)

    // Warga
    val allWarga: Flow<List<WargaEntity>> = database.wargaDao().getAllWarga()
    suspend fun getWargaById(id: String) = database.wargaDao().getWargaById(id)
    suspend fun insertWarga(warga: WargaEntity) = database.wargaDao().insertWarga(warga)
    suspend fun updateWarga(warga: WargaEntity) = database.wargaDao().updateWarga(warga)
    suspend fun deleteWarga(id: String) = database.wargaDao().deleteWarga(id)

    // Kas
    val allKas: Flow<List<KasEntity>> = database.kasDao().getAllKas()
    suspend fun insertKas(kas: KasEntity) = database.kasDao().insertKas(kas)
    suspend fun deleteKas(id: Long) = database.kasDao().deleteKas(id)

    // Iuran
    val allIuran: Flow<List<IuranEntity>> = database.iuranDao().getAllIuran()
    fun getIuranByWarga(wargaId: String): Flow<List<IuranEntity>> = database.iuranDao().getIuranByWarga(wargaId)
    suspend fun insertIuran(iuran: IuranEntity) = database.iuranDao().insertIuran(iuran)
    suspend fun updateIuran(iuran: IuranEntity) = database.iuranDao().updateIuran(iuran)
    suspend fun updateIuranStatus(id: Long, status: String, tanggalBayar: String?) =
        database.iuranDao().updateStatus(id, status, tanggalBayar)
    suspend fun deleteIuran(id: Long) = database.iuranDao().deleteIuran(id)

    // Kegiatan
    val allKegiatan: Flow<List<KegiatanEntity>> = database.kegiatanDao().getAllKegiatan()
    suspend fun insertKegiatan(kegiatan: KegiatanEntity) = database.kegiatanDao().insertKegiatan(kegiatan)
    suspend fun updateKegiatan(kegiatan: KegiatanEntity) = database.kegiatanDao().updateKegiatan(kegiatan)
    suspend fun incrementRsvp(id: Long) = database.kegiatanDao().incrementRsvp(id)
    suspend fun deleteKegiatan(id: Long) = database.kegiatanDao().deleteKegiatan(id)

    // Pengumuman
    val allPengumuman: Flow<List<PengumumanEntity>> = database.pengumumanDao().getAllPengumuman()
    suspend fun insertPengumuman(pengumuman: PengumumanEntity) = database.pengumumanDao().insertPengumuman(pengumuman)
    suspend fun deletePengumuman(id: Long) = database.pengumumanDao().deletePengumuman(id)

    // Surat
    val allSurat: Flow<List<SuratEntity>> = database.suratDao().getAllSurat()
    fun getSuratByWarga(wargaId: String): Flow<List<SuratEntity>> = database.suratDao().getSuratByWarga(wargaId)
    suspend fun insertSurat(surat: SuratEntity) = database.suratDao().insertSurat(surat)
    suspend fun updateSuratStatus(id: Long, status: String) = database.suratDao().updateStatus(id, status)
    suspend fun deleteSurat(id: Long) = database.suratDao().deleteSurat(id)

    suspend fun ensureDataPopulated() {
        if (database.userDao().getCount() == 0) {
            AppDatabase.populateInitialData(database)
        }
    }
}
